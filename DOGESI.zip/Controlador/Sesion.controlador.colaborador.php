<?php

require_once '../Negocio/SesionColaborador.class.php';
require_once '../util/funciones/Funciones.class.php';

$usuario = $_POST["txtusuario"];
$clave = $_POST["txtclave"];
if(isset($_POST["chkrecordar"])){
    $recordar = $_POST["chkrecordar"];
}else{
    $recordar = "N";
}
    


//echo $email,"<br>";
//echo $clave,"<br>";
//echo $recordar,"<br>";
//echo '<pre>';
//print_r($_POST);
//echo '</pre>';

$objSesion  = new SesionColaborador();


//print_r($_POST);
//$correo = $_POST["txtemail"];

$objSesion ->setUsuario($usuario);
$objSesion ->setClave($clave);
$objSesion ->setRecordar($recordar);

try {
    $resultado = $objSesion->iniciarSesionColaborador();
} catch (Exception $exc) {
    //imprmir el error
    Funciones::mensaje($exc->getMessage(),"e", "../Vista/index.php", 1);
}

//echo '<pre>';
//echo '<h1>';
//echo '<div align="center" style="color: red">';
//echo $resultado;
//echo '</h1>';
//echo '</pre>';

switch ($resultado){
    case 1:
        header("location:../Vista/principal.php");
        break;
    
    case 2:
//        echo '<pre>';
//        echo '<h1>';
//        echo '<div align="center" style="color: red">';
        Funciones::mensaje("El usuario se encuentra inactivo", "a","../Vista/index.php", 2);
//        echo '</h1>';
//        echo '</pre>';
        break;
    
        default :
//        echo '<pre>';
//        echo '<h1>';
//        echo '<div align="center" style="color: red">';
        Funciones::mensaje("El usuario o contraceña son incorrectos", "a","../Vista/index.php", 3);
//        echo '</h1>';
//        echo '</pre>';
        break;
}




