<?php
require_once '../Negocio/Area.class.php';
parse_str($_POST["p_array_datos"],$datosFrm);

$objMotivoMovimiento= new Area();

if($datosFrm["txttipooperacion"]=="editar"){
    $objMotivoMovimiento->setIdarea($datosFrm["txtnroarea"]);
}

//$objSolicitante->setIdsolicitante($datosFrm["txtnrosolicitante"]);
$objMotivoMovimiento->setNombrearea($datosFrm["txtnombreareamantenimiento"]);
$objMotivoMovimiento->setSiglas($datosFrm["txtsiglasareamantenimiento"]);
$objMotivoMovimiento->setIdunidadmunicipal($datosFrm["cbounidadmunicipal_moda"]);




try {
    if($datosFrm["txttipooperacion"]=="agregarmanteniemiento"){
        if($objMotivoMovimiento->agregarAreaMantenimiento()==true){
            echo "exito";
        }
    }else{
        if($objMotivoMovimiento->editar()==true){
            echo "exito";
        }
    }
    
} catch (Exception $ex) {
    header("HTTP/1.1 500");
    echo $ex->getMessage();
}

