<?php

require_once '../Negocio/Area.class.php';

$codigo_area= $_POST["p_codigo_area"];

$objSolicitante= new Area();

try {
            $objSolicitante->setIdarea($codigo_area);
            if($objSolicitante->eliminar()){
                echo "exito";
            }
            
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }