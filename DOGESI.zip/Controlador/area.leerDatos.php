<?php

require_once '../Negocio/Area.class.php';

$codigo_area= $_POST["p_codigo_area"];

$objSolicitante= new Area();

try {
            $resultado= $objSolicitante->leerDatos($codigo_area);
            echo json_encode($resultado);
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }



        