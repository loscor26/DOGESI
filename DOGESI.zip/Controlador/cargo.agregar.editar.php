<?php
require_once '../Negocio/Cargo.class.php';
parse_str($_POST["p_array_datos"],$datosFrm);

$objMotivoMovimiento= new Cargo();

if($datosFrm["txttipooperacion"]=="editar"){
    $objMotivoMovimiento->setIdcargo($datosFrm["txtnrocargo"]);
}

//$objSolicitante->setIdsolicitante($datosFrm["txtnrosolicitante"]);
$objMotivoMovimiento->setNombrecargo($datosFrm["txtnombrecargomantenimiento"]);
$objMotivoMovimiento->setIdarea($datosFrm["cboarea_moda"]);




try {
    if($datosFrm["txttipooperacion"]=="agregarmanteniemiento"){
        if($objMotivoMovimiento->agregarCargoMantenimiento()==true){
            echo "exito";
        }
    }else{
        if($objMotivoMovimiento->editar()==true){
            echo "exito";
        }
    }
    
} catch (Exception $ex) {
    header("HTTP/1.1 500");
    echo $ex->getMessage();
}

