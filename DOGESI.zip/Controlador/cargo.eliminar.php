<?php

require_once '../Negocio/Cargo.class.php';

$codigo_cargo= $_POST["p_codigo_cargo"];

$objSolicitante= new Cargo();

try {
            $objSolicitante->setIdcargo($codigo_cargo);
            if($objSolicitante->eliminar()){
                echo "exito";
            }
            
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }