<?php

require_once '../Negocio/Cargo.class.php';

$codigo_cargo= $_POST["p_codigo_cargo"];

$objSolicitante= new Cargo();

try {
            $resultado= $objSolicitante->leerDatos($codigo_cargo);
            echo json_encode($resultado);
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }



        