<?php

session_name("SistemaComercial");
session_start();

unset($_SESSION["usuario"]);
unset($_SESSION["cargo"]);

session_destroy();

header("location:../Vista/index.php");

