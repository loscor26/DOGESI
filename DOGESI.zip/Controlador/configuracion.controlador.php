<?php

require_once '../Negocio/Configuracion.class.php';
require_once '../util/funciones/Funciones.class.php';

$codigoConfiguracion = $_POST["p_codigo"];

$objConf = new Configuracion();
$resultado = $objConf->obtenerValor($codigoConfiguracion);


echo $resultado ["valor"];