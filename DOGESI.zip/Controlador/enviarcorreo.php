<?php


$destino = $_POST['txtemailregistrarsolicitante'];
$nombre = $_POST['txtnombrenatural'];
$apellido= $_POST['txtapelidosnatural'];
$dni= $_POST['txtdni'];
$usuario= $_POST['txtusuario'];
$clave = $_POST['txtclave'];
$direcion= $_POST['txtdireccionregistrosolicitante'];
$email= $_POST['txtemailregistrarsolicitante'];
$contenido = "Nombre :" . $nombre .",".$apellido."\nDireccion:" .$direcion."\nDNI:" .$dni."\nUsuario:".$usuario."\nClave:".$clave;


$asunto ='Confirmacion de Solicitante';
$cabecera = 'From : remitente@dominio.com' . "\r\n" .
            'Reply-To : remitente@dominio.com' . "\r\n" .
            'X-Mailer : PHP/'. phpversion();

if(mail($destino, $asunto, $contenido, $cabecera)){
   echo "exito" ;
}else{
    echo 'Error al enviar mensajes';
}


?>



