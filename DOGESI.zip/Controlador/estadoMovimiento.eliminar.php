<?php

require_once '../Negocio/EstadoMovimiento.class.php';

$codigo_estadomovimiendo= $_POST["p_codigo_estadomovimiendo"];

$objEstadoMovimiento= new EstadoMovimiento();

try {
            $objEstadoMovimiento->setIdestadomovimiento($codigo_estadomovimiendo);
            if($objEstadoMovimiento->eliminar()){
                echo "exito";
            }
            
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }