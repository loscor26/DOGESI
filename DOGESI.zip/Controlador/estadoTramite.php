<?php

require_once '../Negocio/Solicitante.class.php';
require_once '../util/funciones/Funciones.class.php';

$codigo_marca = $_POST["p_codigo_marca"];
$codigo_linea = $_POST["p_codigo_linea"];
$codigo_categoria = $_POST["p_codigo_categoria"];


$objArticulo = new Solicitante();



?>

<table id="tbl-listado" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>AÑO</th>
									<th>HORA</th>
									<th>SOLICITANTE</th>
									<th>ASUNTO</th>
									<th>TRAMITE</th>
                                                                        <th>ESTADO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
								
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
							</tbody>
							<tfoot>
								<tr>
									<th>AÑO</th>
									<th>HORA</th>
									<th>SOLICITANTE</th>
									<th>ASUNTO</th>
									<th>TRAMITE</th>
                                                                        <th>ESTADO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</tfoot>
						</table>



