<?php

require_once '../Negocio/Personal.class.php';
require_once '../util/funciones/Funciones.class.php';

$codigo_unidadmunicipal= $_POST["p_codigo_unidadmunicipal"];
$codigo_area= $_POST["p_codigo_area"];
$codigo_cargo= $_POST["p_codigo_cargo"];


$objPersonal = new Personal();

try {
    $registros = $objPersonal ->listar3ParametroPersonal($codigo_unidadmunicipal, $codigo_area, $codigo_cargo);
} catch (Exception $exc) {
    Funciones::mensaje($exc->getMessage(), "e");
}

?>

<table id="tbl-listado" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>ID</th>
									<th>PERSONAL </th>
									<th>ESTADO</th>
									<th>EMAIL </th>
									<th>DNI</th>
                                                                        <th>USUARIO</th>
                                                                        <th>FECH. INICIO</th>
                                                                        <th>FECH. FIN</th>
                                                                        <th>UNIDAD MUNICIPAL</th>
                                                                        <th>AREA</th>
                                                                        <th>CARGO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
								<?php
                                                                for ($i = 0; $i < count($registros); $i++) {
                                                                    echo '<tr>';
                                                                        echo '<td>'.$registros[$i]["codigo"].'</td>';
                                                                        echo '<td>'.$registros[$i]["nombrecompleto"].'</td>';
                                                                        echo '<td>'.$registros[$i]["estado"].'</td>';
                                                                        echo '<td>'.$registros[$i]["email"].'</td>';
                                                                        echo '<td>'.$registros[$i]["dni"].'</td>';
                                                                        echo '<td>'.$registros[$i]["usuario"].'</td>';
                                                                        echo '<td>'.$registros[$i]["fechainicio"].'</td>';
                                                                        echo '<td>'.$registros[$i]["fechafin"].'</td>';
                                                                        echo '<td>'.$registros[$i]["unidadmunicipal"].'</td>';
                                                                        echo '<td>'.$registros[$i]["area"].'</td>';
                                                                        echo '<td>'.$registros[$i]["cargo"].'</td>';
                                                                        echo '
                                                                                <td>
                                                                                    <a href="javascript:void();" onclick = "editar('.$registros[$i]["codigo"].')" data-toggle="modal" data-target="#myModal"><i class="fa fa-edit text-green"></i></a>
                                                                                    <a href="javascript:void();" onclick = "cambiarestado('.$registros[$i]["codigo"].')"><i class="fa fa-dropbox text-blue"></i></a>  
                                                                                    <a href="javascript:void();" onclick = "eliminar('.$registros[$i]["codigo"].')"><i class="fa fa-trash text-orange"></i></a>
                                                                                </td>
                                                                                ';
                                                                    echo '</tr>';
                                                                }
                                                                ?>
							</tbody>
							<tfoot>
								<tr>
									<th>ID</th>
									<th>PERSONAL </th>
									<th>ESTADO</th>
									<th>EMAIL </th>
									<th>DNI</th>
                                                                        <th>USUARIO</th>
                                                                        <th>FECH. INICIO</th>
                                                                        <th>FECH. FIN</th>
                                                                        <th>UNIDAD MUNICIPAL</th>
                                                                        <th>AREA</th>
                                                                        <th>CARGO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</tfoot>
						</table>



