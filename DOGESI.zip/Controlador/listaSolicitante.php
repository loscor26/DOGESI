<?php

require_once '../Negocio/Solicitante.class.php';
require_once '../util/funciones/Funciones.class.php';

$codigo_departamento = $_POST["p_codigo_departamento"];
$codigo_provincia = $_POST["p_codigo_provincia"];
$codigo_distrito = $_POST["p_codigo_distrito"];


$objSolicitante = new Solicitante();

try {
    $registros = $objSolicitante ->listar3ParametroSolicitante($codigo_departamento, $codigo_provincia, $codigo_distrito);
} catch (Exception $exc) {
    Funciones::mensaje($exc->getMessage(), "e");
}

?>

<table id="tbl-listado" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>ID</th>
                                                                        <th>ESTADO</th>
									<th>DNI </th>
									<th>SOLICITANTE</th>
									<th>DIRECCION </th>
									<th>EMAIL</th>
                                                                        <th>DEPARTAMENTO</th>
                                                                        <th>PROVINCIA</th>
                                                                        <th>DISTRITO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
								<?php
                                                                for ($i = 0; $i < count($registros); $i++) {
                                                                    echo '<tr>';
                                                                        echo '<td>'.$registros[$i]["codigo"].'</td>';
                                                                        echo '<td>'.$registros[$i]["estado"].'</td>';
                                                                        echo '<td>'.$registros[$i]["dnipersonanatural"].'</td>';
                                                                        echo '<td>'.$registros[$i]["nombrecompleto"].'</td>';
                                                                        echo '<td>'.$registros[$i]["direccion"].'</td>';
                                                                        echo '<td>'.$registros[$i]["email"].'</td>';
                                                                        echo '<td>'.$registros[$i]["departamento"].'</td>';
                                                                        echo '<td>'.$registros[$i]["provincia"].'</td>';
                                                                        echo '<td>'.$registros[$i]["distrito"].'</td>';
                                                                        echo '
                                                                                <td>
                                                                                    <a href="javascript:void();" onclick = "editar('.$registros[$i]["codigo"].')" data-toggle="modal" data-target="#myModal"><i class="fa fa-edit text-green"></i></a>
                                                                                    <a href="javascript:void();" onclick = "cambiarestado('.$registros[$i]["codigo"].')"><i class="fa fa-dropbox text-blue"></i></a>  
                                                                                    <a href="javascript:void();" onclick = "eliminar('.$registros[$i]["codigo"].')"><i class="fa fa-trash text-red"></i></a>
                                                                                </td>
                                                                                ';
                                                                    echo '</tr>';
                                                                }
                                                                ?>
							</tbody>
							<tfoot>
								<tr>
									<th>ID</th>
                                                                        <th>ESTADO</th>
									<th>DNI </th>
									<th>SOLICITANTE</th>
									<th>DIRECCION </th>
									<th>EMAIL</th>
                                                                        <th>DEPARTAMENTO</th>
                                                                        <th>PROVINCIA</th>
                                                                        <th>DISTRITO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</tfoot>
						</table>


