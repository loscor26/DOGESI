<?php

require_once '../Negocio/Cargo.class.php';
require_once '../util/funciones/Funciones.class.php';



$codigo_unidadmunicipal= $_POST["p_codigo_unidadmunicipal"];
$codigo_area= $_POST["p_codigo_area"];



$objSolicitante = new Cargo();

try {
    $registros = $objSolicitante ->listar2ParametroCargo($codigo_unidadmunicipal,$codigo_area);
} catch (Exception $exc) {
    Funciones::mensaje($exc->getMessage(), "e");
}

?>

<table id="tbl-listado" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>ID</th>
									<th>CARGO</th>
                                                                        <th>AREA</th>
									<th>UNIDAD MUNICIPAL</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
								<?php
                                                                for ($i = 0; $i < count($registros); $i++) {
                                                                    echo '<tr>';
                                                                        echo '<td>'.$registros[$i]["idcargo"].'</td>';
                                                                        echo '<td>'.$registros[$i]["nombrecargo"].'</td>';
                                                                        echo '<td>'.$registros[$i]["nombrearea"].'</td>';
                                                                        echo '<td>'.$registros[$i]["nombreunidadmunicipal"].'</td>';
                                                                        
                                                                        echo '
                                                                                <td>
                                                                                    <a href="javascript:void();" onclick = "editar('.$registros[$i]["idcargo"].')" data-toggle="modal" data-target="#myModal"><i class="fa fa-edit text-green"></i></a>
                                                                                    
                                                                                    <a href="javascript:void();" onclick = "eliminar('.$registros[$i]["idcargo"].')"><i class="fa fa-trash text-orange"></i></a>
                                                                                </td>
                                                                                ';
                                                                    echo '</tr>';
                                                                }
                                                                ?>
							</tbody>
							<tfoot>
								<tr>
									<th>ID</th>
									<th>CARGO</th>
                                                                        <th>AREA</th>
									<th>UNIDAD MUNICIPAL</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</tfoot>
						</table>


