<?php

require_once '../Negocio/Area.class.php';
require_once '../util/funciones/Funciones.class.php';

$objArea= new Area();
$modal= $_POST["p_modal"];
$codigo_unidadmunicipal= $_POST["p_codigo_unidadmunicipal"];

        try {
            $resultado= $objArea->obtenerArea($codigo_unidadmunicipal);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
            Funciones::mensaje($exc->getMessage(), "e");
        }
        
        if($modal=="0"){
            echo '<option value="0">Todas las Area</option>';
        }else{
            echo '<option value="">Seleccione una Area</option>';
        }
        
 
    for ($i=0; $i<count($resultado); $i++) {
        echo '<option value="'.$resultado[$i]["idarea"].'">'.$resultado[$i]["nombrearea"].'</option>';
    }



