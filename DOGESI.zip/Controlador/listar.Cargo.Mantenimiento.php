<?php

require_once '../Negocio/Area.class.php';
require_once '../util/funciones/Funciones.class.php';



$codigo_unidadmunicipal= $_POST["p_codigo_unidadmunicipal"];



$objSolicitante = new Area();

try {
    $registros = $objSolicitante ->listar1ParametroArea($codigo_unidadmunicipal);
} catch (Exception $exc) {
    Funciones::mensaje($exc->getMessage(), "e");
}

?>

<table id="tbl-listado" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>ID</th>
                                                                        <th>AREA</th>
									<th>SIGLAS</th>
									<th>UNIDAD MUNICIPAL</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
								<?php
                                                                for ($i = 0; $i < count($registros); $i++) {
                                                                    echo '<tr>';
                                                                        echo '<td>'.$registros[$i]["idarea"].'</td>';
                                                                        echo '<td>'.$registros[$i]["nombrearea"].'</td>';
                                                                        echo '<td>'.$registros[$i]["siglas"].'</td>';
                                                                        echo '<td>'.$registros[$i]["nombreunidadmunicipal"].'</td>';
                                                                        
                                                                        echo '
                                                                                <td>
                                                                                    <a href="javascript:void();" onclick = "editar('.$registros[$i]["idarea"].')" data-toggle="modal" data-target="#myModal"><i class="fa fa-edit text-green"></i></a>
                                                                                    
                                                                                    <a href="javascript:void();" onclick = "eliminar('.$registros[$i]["idarea"].')"><i class="fa fa-trash text-orange"></i></a>
                                                                                </td>
                                                                                ';
                                                                    echo '</tr>';
                                                                }
                                                                ?>
							</tbody>
							<tfoot>
								<tr>
									<th>ID</th>
                                                                        <th>AREA</th>
									<th>SIGLAS</th>
									<th>UNIDAD MUNICIPAL</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</tfoot>
						</table>


