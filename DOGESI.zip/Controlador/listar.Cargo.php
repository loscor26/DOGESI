<?php

require_once '../Negocio/Cargo.class.php';
require_once '../util/funciones/Funciones.class.php';

$objCargo= new Cargo();
$modal= $_POST["p_modal"];
$codigo_area= $_POST["p_codigo_area"];

        try {
            $resultado= $objCargo->obtenerCargo($codigo_area);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
            Funciones::mensaje($exc->getMessage(), "e");
        }
        
        if($modal=="0"){
            echo '<option value="0">Todos los Cargos</option>';
        }else{
            echo '<option value="">Seleccione un Cargo</option>';
        }
        
 
    for ($i=0; $i<count($resultado); $i++) {
        echo '<option value="'.$resultado[$i]["idcargo"].'">'.$resultado[$i]["nombrecargo"].'</option>';
    }



