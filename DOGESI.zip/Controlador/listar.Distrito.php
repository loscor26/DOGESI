<?php

require_once '../Negocio/Distrito.php';
require_once '../util/funciones/Funciones.class.php';

$objDistrito= new Distrito();
$modal= $_POST["p_modal"];
$codigo_provincia= $_POST["p_codigo_provincia"];

        try {
            $resultado= $objDistrito->obtenerDistrito($codigo_provincia);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
            Funciones::mensaje($exc->getMessage(), "e");
        }
        
        if($modal=="0"){
            echo '<option value="0">Todos los Distrito</option>';
        }else{
            echo '<option value="">Seleccione un Distrito</option>';
        }
        
 
    for ($i=0; $i<count($resultado); $i++) {
        echo '<option value="'.$resultado[$i]["iddistrito"].'">'.$resultado[$i]["nombredistrito"].'</option>';
    }



