<?php

require_once '../Negocio/Provincia.php';
require_once '../util/funciones/Funciones.class.php';

$objProvincia= new Provincia();
$modal= $_POST["p_modal"];
$codigo_departamento= $_POST["p_codigo_departamento"];

        try {
            $resultado= $objProvincia->obtenerProvincia($codigo_departamento);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
            Funciones::mensaje($exc->getMessage(), "e");
        }
        
        if($modal=="0"){
            echo '<option value="0">Todas las Provincia</option>';
        }else{
            echo '<option value="">Seleccione una Provincia</option>';
        }
        
 
    for ($i=0; $i<count($resultado); $i++) {
        echo '<option value="'.$resultado[$i]["idprovincia"].'">'.$resultado[$i]["nombreprovincia"].'</option>';
    }



