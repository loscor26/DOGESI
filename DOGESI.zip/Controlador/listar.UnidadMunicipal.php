<?php

require_once '../Negocio/UnidadMunicipal.class.php';
require_once '../util/funciones/Funciones.class.php';

$modal= $_GET["modal"];

$objUnidadMunicipal= new UnidadMunicipal();


        try {
            $resultado = $objUnidadMunicipal->obtenerUnidadMunicipal();
        } catch (Exception $exc) {
            Funciones::mensaje($exc->getMessage(), "e");
        }
        
        if($modal=="0"){
            echo '<option value="0">Todos las Unidades</option>';
        }else{
            echo '<option value="">Seleccione un Unidad Municipal</option>';
        }
     
        
    for ($i = 0; $i < count($resultado); $i++) {
        echo'<option value="'.$resultado[$i]["idunidadmunicipal"].'">'.$resultado[$i]["nombreunidadmunicipal"].'</option>';
        
    }



