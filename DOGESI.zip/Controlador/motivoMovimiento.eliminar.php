<?php

require_once '../Negocio/MotivoMovimiento.class.php';

$codigo_motivomovimiendo= $_POST["p_codigo_motivomovimiendo"];

$objMotivoMovimiento= new MotivoMovimiento();

try {
            $objMotivoMovimiento->setIdmotivomovimiento($codigo_motivomovimiendo);
            if($objMotivoMovimiento->eliminar()){
                echo "exito";
            }
            
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }