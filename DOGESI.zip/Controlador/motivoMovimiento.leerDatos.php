<?php

require_once '../Negocio/MotivoMovimiento.class.php';

$codigo_motivomovimiendo= $_POST["p_codigo_motivomovimiendo"];

$objMotivoMovimiento= new MotivoMovimiento();

try {
            $resultado= $objMotivoMovimiento->leerDatos($codigo_motivomovimiendo);
            echo json_encode($resultado);
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }



        