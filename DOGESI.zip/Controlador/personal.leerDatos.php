<?php

require_once '../Negocio/Personal.class.php';

$codigo_personal= $_POST["p_codigo_personal"];

$objPersonal= new Personal();

try {
            $resultado= $objPersonal->leerDatos($codigo_personal);
            echo json_encode($resultado);
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }



        