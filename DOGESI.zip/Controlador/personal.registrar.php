<?php
require_once '../Negocio/Personal.class.php';
parse_str($_POST["p_array_datos"],$datosFrm);

$objPersonal= new Personal();

if($datosFrm["txttipooperacion"]=="editar"){
    $objPersonal->setIdpersonal($datosFrm["txtnropersonal"]);
}

//$objSolicitante->setIdsolicitante($datosFrm["txtnrosolicitante"]);
$objPersonal->setUsuario($datosFrm["txtusuariopersonal"]);
$objPersonal->setClave($datosFrm["txtclavepersonal"]);
$objPersonal->setFechainicio($datosFrm["txtfechainiciopersonal"]);
$objPersonal->setFechafin($datosFrm["txtfechafinpersonal"]);
$objPersonal->setDireccion($datosFrm["txtdireccionpersonal"]);
$objPersonal->setEmail($datosFrm["txtemailpersonal"]);
$objPersonal->setNombre($datosFrm["txtnombrepersonal"]);
$objPersonal->setApellidos($datosFrm["txtapellidospersonal"]);
$objPersonal->setDnipersonal($datosFrm["txtdnipersonal"]);
$objPersonal->setIdcargo($datosFrm["cbocargo_modal"]);



try {
    if($datosFrm["txttipooperacion"]=="agregarmanteniemiento"){
        if($objPersonal->agregarPersonal()==true){
            echo "exito";
        }
    }else{
        if($objPersonal->editar()==true){
            echo "exito";
        }
    }
    
} catch (Exception $ex) {
    header("HTTP/1.1 500");
    echo $ex->getMessage();
}

