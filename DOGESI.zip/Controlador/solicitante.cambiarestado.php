<?php

require_once '../Negocio/Solicitante.class.php';

$codigo_solicitante= $_POST["p_codigo_solicitantemantenimiento"];

$objSolicitanteMentenimiento = new Solicitante();

//$objSolicitanteMentenimiento= new Solicitante();

try {
            $objSolicitanteMentenimiento->setIdsolicitante($codigo_solicitante);
            if($objSolicitanteMentenimiento->cambiarestado()){
                echo "exito";
            }
            
            print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
            Funciones::mensaje($exc->getMessage(), "e");
        }