<?php

require_once '../Negocio/Solicitante.class.php';

$codigo_solicitante= $_POST["p_codigo_solicitante"];

$objSolicitante= new Solicitante();

try {
            $resultado= $objSolicitante->leerDatos($codigo_solicitante);
            echo json_encode($resultado);
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }



        