<?php
require_once '../Negocio/Solicitante.class.php';
parse_str($_POST["p_array_datos"],$datosFrm);

$objSolicitanteMentenimiento = new Solicitante();

if($datosFrm["txttipooperacion"]=="editar"){
    $objSolicitanteMentenimiento->setIdsolicitante($datosFrm["txtnrosolicitante"]);
}

//$objSolicitante->setIdsolicitante($datosFrm["txtnrosolicitante"]);
$objSolicitanteMentenimiento->setDireccionSolicitante($datosFrm["txtdireccionregistrosolicitante"]);
$objSolicitanteMentenimiento->setDnipersonanatural($datosFrm["txtdni"]);
$objSolicitanteMentenimiento->setApellidospersonanatural($datosFrm["txtapelidosnatural"]);
$objSolicitanteMentenimiento->setNombrepersonanatural($datosFrm["txtnombrenatural"]);
$objSolicitanteMentenimiento->setRucpersonajuridica($datosFrm["txtruc"]);
$objSolicitanteMentenimiento->setRazonsocialpersonajuridica($datosFrm["txtrazonsocialpersonajuridica"]);
$objSolicitanteMentenimiento->setIddistrito($datosFrm["cbodistrito_modal"]);
$objSolicitanteMentenimiento->setEmailSolicitante($datosFrm["txtemailregistrarsolicitante"]);
$objSolicitanteMentenimiento->setUsuario($datosFrm["txtusuario"]);
$objSolicitanteMentenimiento->setClave($datosFrm["txtclave"]);



try {
    if($datosFrm["txttipooperacion"]=="agregarmanteniemiento"){
        if($objSolicitanteMentenimiento->agregarSolicitanteSolicitante()==true){
            echo "exito";
        }
    }else{
        if($objSolicitanteMentenimiento->editar()==true){
            echo "exito";
        }
    }
    
} catch (Exception $ex) {
    header("HTTP/1.1 500");
    echo $ex->getMessage();
}

