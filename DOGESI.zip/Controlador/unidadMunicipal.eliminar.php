<?php

require_once '../Negocio/UnidadMunicipal.class.php';

$codigo_unidadmunicipal= $_POST["p_codigo_unidadmunicipal"];

$objMotivoMovimiento= new UnidadMunicipal();

try {
            $objMotivoMovimiento->setIdunidadmunicipal($codigo_unidadmunicipal);
            if($objMotivoMovimiento->eliminar()){
                echo "exito";
            }
            
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }