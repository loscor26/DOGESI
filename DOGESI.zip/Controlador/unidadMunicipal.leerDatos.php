<?php

require_once '../Negocio/UnidadMunicipal.class.php';

$codigo_unidadmunicipal= $_POST["p_codigo_unidadmunicipal"];

$objEstadoMovimiento= new UnidadMunicipal();

try {
            $resultado= $objEstadoMovimiento->leerDatos($codigo_unidadmunicipal);
            echo json_encode($resultado);
            //print_r($resultado);
        } catch (Exception $exc) {
            header ("HTTP/1.1 500"); 
            echo $exc->getMessage();
//            Funciones::mensaje($exc->getMessage(), "e");
        }



        