<?php
    
    require_once 'Configuracion.php';
    require_once '../util/funciones/Funciones.class.php';
    
    class Conexion{
        protected $dblink ;
         
        public function __construct() {
            $this->abrirConexion();
//            echo "Conexion abierta";
        }

        public function __destruct() {
            $this->dblink=NULL;
//            echo "Conexion cerrada";
        }

        protected function abrirConexion(){
            $servidor="pgsql:host=".SERVIDO_BD.";port=".PUERTO_BD.";dbname=".NOMBRE_BD;
            $usuario =USUARIO_BD;
            $clave = CLAVE_BD;
            
            try {
                $this->dblink = new PDO($servidor, $usuario, $clave);
                $this->dblink->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            } catch (Exception $exc) {
                Funciones::mensaje($exc->getMessage(), "e");
                //echo $exc->getMessage();
            }

            $this->dblink = new PDO($servidor, $usuario, $clave);
            
            return $this->dblink;
        }
    }


