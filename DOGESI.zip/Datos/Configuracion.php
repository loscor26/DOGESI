<?php

    define("SERVIDO_BD","localhost");
    define("USUARIO_BD","postgres");
    define("CLAVE_BD","programacion3");
    define("PUERTO_BD","5432");
    define("NOMBRE_BD","DOGESI");
   
    
//    define("SERVIDO_BD","ec2-54-227-237-223.compute-1.amazonaws.com");
//    define("USUARIO_BD","pnbngbbbeqysfz");
//    define("CLAVE_BD","2767f102015cf56e15284b95e790dff062cce03e881451ce483781c15868798a");
//    define("PUERTO_BD","5432");
//    define("NOMBRE_BD","d1lgig6skep2ni");

