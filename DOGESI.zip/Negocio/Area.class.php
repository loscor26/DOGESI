<?php

require_once '../Datos/Conexion.php'; 
class Area extends Conexion {
    
    private $idarea;
    private $nombrearea;
    private $siglas;
    private $idunidadmunicipal;
    function getSiglas() {
        return $this->siglas;
    }

    function getIdunidadmunicipal() {
        return $this->idunidadmunicipal;
    }

    function setSiglas($siglas) {
        $this->siglas = $siglas;
    }

    function setIdunidadmunicipal($idunidadmunicipal) {
        $this->idunidadmunicipal = $idunidadmunicipal;
    }

        
    function getIdarea() {
        return $this->idarea;
    }

    function getNombrearea() {
        return $this->nombrearea;
    }

    function setIdarea($idarea) {
        $this->idarea = $idarea;
    }

    function setNombrearea($nombrearea) {
        $this->nombrearea = $nombrearea;
    }
    
     public function  listar1ParametroArea($codigoUnidadMunicipal){
        
        try {
            $sql = "select * from f_listar_area(:codigo_UnidadMunicipal)";
        $sentencia  = $this->dblink->prepare($sql);
        $sentencia->bindParam(":codigo_UnidadMunicipal",$codigoUnidadMunicipal);
        
        $sentencia->execute();
         
        $registros = $sentencia->fetchAll();
        
        return $registros;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
  
    

 public function obtenerArea($codigoUnidadMunicipal){
        try {
            $sql = "select a.idarea,a.nombrearea from area a 
	inner join unidadmunicipal um on (a.idunidadmunicipal = um.idunidadmunicipal)
	where a.idunidadmunicipal=:codigoUnidadMunicipal order by a.nombrearea

";
            $sentencia  = $this->dblink->prepare($sql);
            $sentencia->bindParam(":codigoUnidadMunicipal",$codigoUnidadMunicipal);
            $sentencia->execute();
         
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    
    
     public function agregarAreaMantenimiento(){
        try {
                
                $sql = "INSERT INTO area(
                        nombrearea, siglas, idunidadmunicipal)
                        VALUES (:p_nombrearea, 
                    :p_siglas,
                    :p_idunidadmunicipal)";
                $sentencia = $this->dblink->prepare($sql);
               
                $sentencia->bindParam(":p_nombrearea", $this->getNombrearea());
                $sentencia->bindParam(":p_siglas", $this->getSiglas());
                $sentencia->bindParam(":p_idunidadmunicipal", $this->getIdunidadmunicipal());
                
          
                
               $sentencia->execute();
            
       } catch (Exception $exc) {
            echo $exc;
        }
        return true;  
    }
    
     public function leerDatos($codigo_area) {
        try {
            $sql = "
                SELECT a.idarea, a.nombrearea, a.siglas, um.idunidadmunicipal
            FROM area a
                inner join unidadmunicipal um on (a.idunidadmunicipal=um.idunidadmunicipal)
                where a.idarea=:p_ca
                ";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_area);
            $sentencia->execute();
            $resultado = $sentencia->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (Exception $exc) {
            throw $exc;
        }
        }
    
    
    public function editar (){
            $this->dblink->beginTransaction();
        try {
                $sql = "UPDATE area SET nombrearea=:p_nombrearea, siglas=:p_siglas, 
                idunidadmunicipal=:p_idunidadmunicipal
                WHERE idarea =:p_idarea";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia ->bindParam(":p_idarea",  $this->getIdarea());
                $sentencia->bindParam(":p_nombrearea", $this->getNombrearea());
                $sentencia->bindParam(":p_siglas", $this->getSiglas());
                $sentencia->bindParam(":p_idunidadmunicipal", $this->getIdunidadmunicipal());
                $sentencia ->execute();
                $this->dblink->commit();
        } catch (Exception $exc) {
            $this->dblink->rollBack();
            throw $exc;
        }
        return true;
        }
        
        public function eliminar (){
        try {
           
            $sql ="delete from area   where idarea= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia ->bindParam(":p_ca", $this->getIdarea());
            $sentencia->execute();
           
        } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }

}
