<?php
require_once '../Datos/Conexion.php'; 

class Cargo extends Conexion {
    private $idcargo;
    private $nombrecargo;
    private $idarea;
    
    function getIdarea() {
        return $this->idarea;
    }

    function setIdarea($idarea) {
        $this->idarea = $idarea;
    }

    function getIdcargo() {
        return $this->idcargo;
    }

    function getNombrecargo() {
        return $this->nombrecargo;
    }

    function setIdcargo($idcargo) {
        $this->idcargo = $idcargo;
    }

    function setNombrecargo($nombrecargo) {
        $this->nombrecargo = $nombrecargo;
    }
    
    public function  listar2ParametroCargo($codigoUnidadMunicipal,$codigoArea){
        
        try {
            $sql = "select * from f_listar_cargo(:codigo_UnidadMunicipal,:codigo_area)";
        $sentencia  = $this->dblink->prepare($sql);
        $sentencia->bindParam(":codigo_UnidadMunicipal",$codigoUnidadMunicipal);
        $sentencia->bindParam(":codigo_area",$codigoArea);
        
        $sentencia->execute();
         
        $registros = $sentencia->fetchAll();
        
        return $registros;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    

    public function obtenerCargo($codigoArea){
        try {
            $sql = "
            select c.idcargo,c.nombrecargo from cargo c
	inner join area a on (a.idarea = c.idarea)
	where a.idarea=:codigoArea order by c.nombrecargo";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":codigoArea",$codigoArea);
            $sentencia->execute();
        
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
}

public function agregarCargoMantenimiento(){
        try {
                
                $sql = "INSERT INTO cargo(
                        nombrecargo, idarea)
                        VALUES (:p_nombrecargo, 
                    :p_idarea)";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia->bindParam(":p_nombrecargo", $this->getNombrecargo());
                $sentencia->bindParam(":p_idarea", $this->getIdarea());
               $sentencia->execute();
            
       } catch (Exception $exc) {
            echo $exc;
        }
        return true;  
    }
    
     public function leerDatos($codigo_cargo) {
        try {
            $sql = "
                SELECT c.idcargo,c.nombrecargo, a.idarea, um.idunidadmunicipal
            FROM area a 
            inner join unidadmunicipal um on (a.idunidadmunicipal=um.idunidadmunicipal)
            inner join cargo c on (c.idarea=a.idarea)where c.idcargo=:p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_cargo);
            $sentencia->execute();
            $resultado = $sentencia->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (Exception $exc) {
            throw $exc;
        }
        }
    
    
    public function editar (){
            $this->dblink->beginTransaction();
        try {
                $sql = "UPDATE cargo SET nombrecargo=:p_nombrecargo, idarea=:p_idarea
                WHERE idcargo =:p_idcargo";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia ->bindParam(":p_idcargo",  $this->getIdcargo());
                $sentencia->bindParam(":p_nombrecargo", $this->getNombrecargo());
                $sentencia->bindParam(":p_idarea", $this->getIdarea());
                $sentencia ->execute();
                $this->dblink->commit();
        } catch (Exception $exc) {
            $this->dblink->rollBack();
            throw $exc;
        }
        return true;
        }
        
        public function eliminar (){
        try {
           
            $sql ="delete from cargo   where idcargo= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia ->bindParam(":p_ca", $this->getIdcargo());
            $sentencia->execute();
           
        } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }




}
