<?php
require_once '../Datos/Conexion.php';

class Departamento extends Conexion{
private $iddepartamento;
private $nombredepartamento;

function getIddepartamento() {
    return $this->iddepartamento;
}

function getNombredepartamento() {
    return $this->nombredepartamento;
}

function setIddepartamento($iddepartamento) {
    $this->iddepartamento = $iddepartamento;
}

function setNombredepartamento($nombredepartamento) {
    $this->nombredepartamento = $nombredepartamento;
}

public function obtenerDepartamento(){
        try {
            $sql = "select iddepartamento,nombredepartamento from departamento order by nombredepartamento";
            $sentencia  = $this->dblink->prepare($sql);
        
            $sentencia->execute();
         
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
}
