<?php
require_once '../Datos/Conexion.php'; 

class Distrito extends Conexion {
    private $iddistrito;
    private $nombredistrito;
    
    function getIddistrito() {
        return $this->iddistrito;
    }

    function getNombredistrito() {
        return $this->nombredistrito;
    }

    function setIddistrito($iddistrito) {
        $this->iddistrito = $iddistrito;
    }

    function setNombredistrito($nombredistrito) {
        $this->nombredistrito = $nombredistrito;
    }


    public function obtenerDistrito($codigoProvincia){
        try {
            $sql = "select d.iddistrito,d.nombredistrito from distrito d 
	inner join provincia p on (d.idprovincia = p.idprovincia)
	where p.idprovincia=:codigoProvincia order by d.nombredistrito";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":codigoProvincia",$codigoProvincia);
            $sentencia->execute();
        
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    
    
}
