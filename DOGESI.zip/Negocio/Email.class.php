<?php
require_once '../phpmailer/PHPMailerAutoload.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Email
 *
 * @author RoyStyckAS
 */
class Email 
{
    private $email;
    
    function __construct() 
    {
        $this->email = new PHPMailer();
        $this->email->isSMTP();
        $this->email->SMTPDebug = 0;
        $this->email->Debugoutput = 'html';
        $this->email->Host = 'smtp.gmail.com';
        $this->email->Port = 587;
        $this->email->SMTPAuth = true;
        $this->email->Username = "styck2603@gmail.com";
        $this->email->Password = "programacion3";
        $this->email->setFrom('styck2603@gmail.com', 'DOGESI');
    }
    
    public function enviarMensajeCorreo($to, $subject, $body)
    {
        $this->email->addAddress($to);
        $this->email->Subject = $subject;
        $this->email->msgHTML($body);
        
        return $this->email->send();
    }
}
