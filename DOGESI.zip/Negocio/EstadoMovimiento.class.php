<?php

 require_once '../Datos/Conexion.php';
class EstadoMovimiento extends Conexion{
    private $idestadomovimiento;
    private $nombre;
    
    
    function getIdestadomovimiento() {
        return $this->idestadomovimiento;
    }

    function getNombre() {
        return $this->nombre;
    }

    function setIdestadomovimiento($idestadomovimiento) {
        $this->idestadomovimiento = $idestadomovimiento;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

            
     public function  listarEstadoMovimiento(){
        
       try {
            $sql = "select * from estadomovimiento order by idestadomovimiento";
            $sentencia  = $this->dblink->prepare($sql);
        
            $sentencia->execute();
         
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    
   public function eliminar (){
        try {
           
            $sql ="delete from estadomovimiento   where idestadomovimiento= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $this->getIdestadomovimiento());
            $sentencia->execute();
           
        } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
    
    
    
    
     public function agregarEstadoMovimiento(){
        try {
                
                $sql = "insert into estadomovimiento(nombre)
            values (:p_nombre)";
                $sentencia = $this->dblink->prepare($sql);
               
                $sentencia->bindParam(":p_nombre", $this->getNombre());
               
                
               $sentencia->execute();
            
       } catch (Exception $exc) {
            echo $exc;
        }
        return true;  
    }
    
    
    public function editar (){
            $this->dblink->beginTransaction();
        
        try {
            
                
                $sql = "UPDATE estadomovimiento SET nombre=:p_nombre
                WHERE idestadomovimiento =:p_idestadomovimiento";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia ->bindParam(":p_idestadomovimiento",  $this->getIdestadomovimiento());
                $sentencia ->bindParam(":p_nombre",  $this->getNombre());
                
                
                $sentencia ->execute();
                
                $this->dblink->commit();
                
            
        } catch (Exception $exc) {
            $this->dblink->rollBack();
            throw $exc;
        }
        return true;
        }
        
         public function leerDatos($codigo_estadomovimiento) {
        try {
            $sql = "
                 select idestadomovimiento, nombre from estadomovimiento where idestadomovimiento =:p_ca
                ";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_estadomovimiento);
            $sentencia->execute();
            $resultado = $sentencia->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (Exception $exc) {
            throw $exc;
        }
            
    }


}
