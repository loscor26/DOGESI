<?php
require_once '../Datos/Conexion.php';

class EstadoSolicitante extends Conexion{

public function obtenerEstado(){
        try {
            $sql = "select  (case when estado = 'A' then 'Activo' else 'Inactivo' end)::character varying(15) as estado from solicitante group by estado";
            $sentencia  = $this->dblink->prepare($sql);
        
            $sentencia->execute();
         
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
}
