<?php

 require_once '../Datos/Conexion.php';
 
class MotivoMovimiento extends Conexion{
    private $idmotivomovimiento;
    private $nombre;
    
    
    function getIdmotivomovimiento() {
        return $this->idmotivomovimiento;
    }

    function getNombre() {
        return $this->nombre;
    }

    function setIdmotivomovimiento($idmotivomovimiento) {
        $this->idmotivomovimiento = $idmotivomovimiento;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    
            
     public function  listarMotivoMovimiento(){
        
       try {
            $sql = "select * from motivomovimiento order by idmotivomovimiento";
            $sentencia  = $this->dblink->prepare($sql);
        
            $sentencia->execute();
         
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    
   public function eliminar (){
        try {
           
            $sql ="delete from motivomovimiento   where idmotivomovimiento= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $this->getIdmotivomovimiento());
            $sentencia->execute();
           
        } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
     public function agregarMotivoMovimiento(){
        try {
                
                $sql = "insert into motivomovimiento(nombre)
            values (:p_nombre)";
                $sentencia = $this->dblink->prepare($sql);
               
                $sentencia->bindParam(":p_nombre", $this->getNombre());
               
                
               $sentencia->execute();
            
       } catch (Exception $exc) {
            echo $exc;
        }
        return true;  
    }
    
    
    public function editar (){
            $this->dblink->beginTransaction();
        
        try {
            
                
                $sql = "UPDATE motivomovimiento SET nombre=:p_nombre
                WHERE idmotivomovimiento =:p_idmotivomovimiento";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia ->bindParam(":p_idmotivomovimiento",  $this->getIdmotivomovimiento());
                $sentencia ->bindParam(":p_nombre",  $this->getNombre());
                
                
                $sentencia ->execute();
                
                $this->dblink->commit();
                
            
        } catch (Exception $exc) {
            $this->dblink->rollBack();
            throw $exc;
        }
        return true;
        }
        
         public function leerDatos($codigo_motivomovimiento) {
        try {
            $sql = "
                 select idmotivomovimiento, nombre from motivomovimiento where idmotivomovimiento =:p_ca ";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_motivomovimiento);
            $sentencia->execute();
            $resultado = $sentencia->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (Exception $exc) {
            throw $exc;
        }
            
    }


}
