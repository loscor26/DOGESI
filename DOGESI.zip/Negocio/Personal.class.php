<?php

require_once '../Datos/Conexion.php';
class Personal extends Conexion {
    
    private $idpersonal;
    private $estado;
    private $apellidos;
    private $nombre;
    private $email;
    private $dnipersonal;
    private $usuario;
    private $clave;
    private $fechainicio;
    private $fechafin;
    private $idcargo;
    private $direccion;
    function getClave() {
        return $this->clave;
    }

    function getFechainicio() {
        return $this->fechainicio;
    }

    function getFechafin() {
        return $this->fechafin;
    }

    function getIdcargo() {
        return $this->idcargo;
    }

    function getDireccion() {
        return $this->direccion;
    }

    function setClave($clave) {
        $this->clave = $clave;
    }

    function setFechainicio($fechainicio) {
        $this->fechainicio = $fechainicio;
    }

    function setFechafin($fechafin) {
        $this->fechafin = $fechafin;
    }

    function setIdcargo($idcargo) {
        $this->idcargo = $idcargo;
    }

    function setDireccion($direccion) {
        $this->direccion = $direccion;
    }

        function getIdpersonal() {
        return $this->idpersonal;
    }

    function getEstado() {
        return $this->estado;
    }

    function getApellidos() {
        return $this->apellidos;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getEmail() {
        return $this->email;
    }

    function getDnipersonal() {
        return $this->dnipersonal;
    }

    function getUsuario() {
        return $this->usuario;
    }

    function setIdpersonal($idpersonal) {
        $this->idpersonal = $idpersonal;
    }

    function setEstado($estado) {
        $this->estado = $estado;
    }

    function setApellidos($apellidos) {
        $this->apellidos = $apellidos;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setDnipersonal($dnipersonal) {
        $this->dnipersonal = $dnipersonal;
    }

    function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    public function  listar3ParametroPersonal($codigoUnidadMunicipal,$codigoArea,$codigoCargo){
        
        try {
            $sql = "select * from f_listar_personal(:codigo_unidadmunicipal, :codigo_area, :codigo_cargo)";
        $sentencia  = $this->dblink->prepare($sql);
        $sentencia->bindParam(":codigo_unidadmunicipal",$codigoUnidadMunicipal);
        $sentencia->bindParam(":codigo_area",$codigoArea);
        $sentencia->bindParam(":codigo_cargo",$codigoCargo);
        $sentencia->execute();
         
        $registros = $sentencia->fetchAll();
        
        return $registros;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    
    
    public function eliminar (){
        try {
            
            $sql ="delete from personal where idpersonal= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $this->getIdpersonal());
            $sentencia->execute();
        } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
    public function cambiarestadopersonal(){
        
        try {
           
            $sql ="update personal  set estado ='A' where idpersonal= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $this->getIdpersonal());
            $sentencia->execute();
                
               } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
    
     public function agregarPersonal(){
         //$this->dblink->beginTransaction();
        try {
                
                $sql = "INSERT INTO personal( apellidos, nombre, email, dnipersonal, usuario, clave, 
            fechainicio, fechafin, idcargo, direccion)
            values (:p_apellidos, 
                    :p_nombre,
                    :p_email, 
                    :p_dnipersonal, 
                    :p_usuario, 
                    :p_clave,
                    :p_fechainicio, 
                    :p_fechafin, 
                    :p_idcargo, 
                    :p_direccion)";
                $sentencia = $this->dblink->prepare($sql);
               
                $sentencia->bindParam(":p_apellidos", $this->getApellidos());
                $sentencia->bindParam(":p_nombre", $this->getNombre());
                $sentencia->bindParam(":p_email", $this->getEmail());
                $sentencia->bindParam(":p_dnipersonal", $this->getDnipersonal());
                $sentencia->bindParam(":p_usuario", $this->getUsuario());
                $sentencia->bindParam(":p_clave", $this->getClave());
                $sentencia->bindParam(":p_fechainicio", $this->getFechainicio());
                $sentencia->bindParam(":p_fechafin", $this->getFechafin());
                $sentencia->bindParam(":p_idcargo", $this->getIdcargo());
                $sentencia->bindParam(":p_direccion", $this->getDireccion());
          
                
               $sentencia->execute();
            
       } catch (Exception $exc) {
            echo $exc;
        }
        return true;  
    }
    
    
    public function editar (){
            //$this->dblink->beginTransaction();
        
        try {
                $sql = "UPDATE personal
                SET apellidos=:p_apellidos, nombre=:p_nombre, email=:p_email, dnipersonal=:p_dnipersonal, 
                usuario=:p_usuario, clave=:p_clave, fechainicio=:p_fechainicio, fechafin=:p_fechafin, 
                idcargo=:p_idcargo, direccion=:p_direccion
                WHERE idpersonal =:p_idpersonal";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia ->bindParam(":p_idpersonal",  $this->getIdpersonal());
                $sentencia ->bindParam(":p_apellidos",  $this->getApellidos());
                $sentencia ->bindParam(":p_nombre",  $this->getNombre());
                $sentencia ->bindParam(":p_email",  $this->getEmail());
                $sentencia ->bindParam(":p_dnipersonal",  $this->getDnipersonal());
                $sentencia ->bindParam(":p_usuario",  $this->getUsuario());
                $sentencia ->bindParam(":p_clave",  $this->getClave());
                $sentencia ->bindParam(":p_fechainicio",  $this->getFechainicio());
                $sentencia ->bindParam(":p_fechafin",  $this->getFechafin());
                $sentencia ->bindParam(":p_idcargo",  $this->getIdcargo());
                $sentencia ->bindParam(":p_direccion",  $this->getDireccion());
                
                $sentencia ->execute();
                
                $this->dblink->commit();
                
            
        } catch (Exception $exc) {
            $this->dblink->rollBack();
            throw $exc;
        }
        return true;
        }
        
        
 public function leerDatos($codigo_personal) {
        try {
            $sql = " SELECT p.idpersonal, p.apellidos, p.nombre, p.email, p.dnipersonal, p.usuario, p.clave, 
                p.fechainicio, p.fechafin, p.direccion, c.idcargo,a.idarea, um.idunidadmunicipal
                FROM personal p 
                inner join cargo c on ( p.idcargo = c.idcargo )
                inner join area a on ( c.idarea = a.idarea )
                inner join unidadmunicipal um on ( a.idunidadmunicipal = um.idunidadmunicipal )
                where p.idpersonal=:p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_personal);
            $sentencia->execute();
            $resultado = $sentencia->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (Exception $exc) {
            throw $exc;
        }
            
    }
 
}
