<?php

require_once '../Datos/Conexion.php'; 
class Provincia extends Conexion {
    private $idprovincia;
    private $nombreprovincia;
    
    function getIdprovincia() {
        return $this->idprovincia;
    }

    function getNombreprovincia() {
        return $this->nombreprovincia;
    }

    function setIdprovincia($idprovincia) {
        $this->idprovincia = $idprovincia;
    }

    function setNombreprovincia($nombreprovincia) {
        $this->nombreprovincia = $nombreprovincia;
    }

    public function obtenerProvincia($codigoDepatamento){
        try {
            $sql = "select p.idprovincia,p.nombreprovincia from provincia p 
	inner join departamento dp on (p.iddepartamento = dp.iddepartamento)
	where p. iddepartamento=:codigoDepatamento order by p.nombreprovincia";
            $sentencia  = $this->dblink->prepare($sql);
            $sentencia->bindParam(":codigoDepatamento",$codigoDepatamento);
            $sentencia->execute();
         
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
}
