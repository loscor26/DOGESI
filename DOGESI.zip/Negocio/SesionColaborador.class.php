<?php
require_once '../Datos/Conexion.php';

class SesionColaborador extends Conexion{
    private $usuario;
    private $clave;
    private $recordar;
    
    function getUsuario() {
        return $this->usuario;
    }

    function getClave() {
        return $this->clave;
    }

    function getRecordar() {
        return $this->recordar;
    }

    function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    function setClave($clave) {
        $this->clave = $clave;
    }

    function setRecordar($recordar) {
        $this->recordar = $recordar;
    }

    
    public function iniciarSesionColaborador(){
        try {
            $sql="select p.clave,p.estado, p.apellidos, p.nombre, c.nombrecargo from personal p
	inner join cargo c on(p.idcargo = c.idcargo)
	where p.usuario=:usuario";
        
        $sentencia= $this->dblink->prepare($sql);
        $sentencia->bindParam(":usuario",  $this->getUsuario());
        $sentencia->execute();
        
        $resultado = $sentencia->fetch();
        
        if($resultado["clave"]== ($this->getClave())){
            if($resultado["estado"]== "I"){
                return 2;
            }  else {
            session_name ("MPG");
            session_start();
            $_SESSION["usuario"]= $resultado["nombre"].' , '.$resultado["apellidos"];
     
            $_SESSION["cargo"] =$resultado["nombrecargo"];
            
            
            if($this->getRecordar()=="S"){
            setcookie("usuario",  $this->getUsuario(),0,"/");
            }else{
                setcookie("usuario",  "",0,"/");
            }
           
            return 1;
            }
        }
        return -1;
        } catch (Exception $exc) {
            throw $exc;
        } 
    }
    
}
