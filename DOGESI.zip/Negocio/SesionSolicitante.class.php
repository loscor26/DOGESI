<?php
require_once '../Datos/Conexion.php';

class SesionSolicitante extends Conexion{
    private $usuario;
    private $clave;
    private $recordar;
    function getUsuario() {
        return $this->usuario;
    }

    function getClave() {
        return $this->clave;
    }

    function getRecordar() {
        return $this->recordar;
    }

    function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    function setClave($clave) {
        $this->clave = $clave;
    }

    function setRecordar($recordar) {
        $this->recordar = $recordar;
    }

            

    public function iniciarSesionSolicitante(){
        try {
            $sql="SELECT clave,  
       dnipersonanatural, apellidospersonanatural, nombrepersonanatural, 
       rucpersonajuridica, razonsocialpersonajuridica, estado
        FROM solicitante where usuario =:usuario";
        
        $sentencia= $this->dblink->prepare($sql);
        $sentencia->bindParam(":usuario",  $this->getUsuario());
        $sentencia->execute();
        
        $resultado = $sentencia->fetch();
        
        if($resultado["clave"]== ($this->getClave())){
            if($resultado["estado"]== "I"){
                return 2;
            }  else {
            session_name ("MPG");
            session_start();
            $_SESSION["usuario"]= $resultado["nombrepersonanatural"].' , '.$resultado["apellidospersonanatural"];
            
            if($this->getRecordar()=="S"){
            setcookie("usuario",  $this->getUsuario(),0,"/");
            }else{
                setcookie("usuario",  "",0,"/");
            }
           
            return 1;
            }
        }
        return -1;
        } catch (Exception $exc) {
            throw $exc;
        } 
    }
    
}
