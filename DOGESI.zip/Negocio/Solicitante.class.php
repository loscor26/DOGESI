<?php

 require_once '../Datos/Conexion.php';
 require_once 'Email.class.php';
 
class Solicitante extends Conexion{
    private $idsolicitante;
    private $direccionSolicitante;
    private $emailSolicitante;
    private $dnipersonanatural;
    private $apellidospersonanatural;
    private $nombrepersonanatural;
    private $rucpersonajuridica;
    private $razonsocialpersonajuridica;
    private $iddistrito;
    private $usuario;
    private $clave;
      
    
    function getIdsolicitante() {
        return $this->idsolicitante;
    }

    function getDireccionSolicitante() {
        return $this->direccionSolicitante;
    }

    function getEmailSolicitante() {
        return $this->emailSolicitante;
    }

    function getDnipersonanatural() {
        return $this->dnipersonanatural;
    }

    function getApellidospersonanatural() {
        return $this->apellidospersonanatural;
    }

    function getNombrepersonanatural() {
        return $this->nombrepersonanatural;
    }

    function getRucpersonajuridica() {
        return $this->rucpersonajuridica;
    }

    function getRazonsocialpersonajuridica() {
        return $this->razonsocialpersonajuridica;
    }

    function getIddistrito() {
        return $this->iddistrito;
    }

    function getUsuario() {
        return $this->usuario;
    }

    function getClave() {
        return $this->clave;
    }

    function setIdsolicitante($idsolicitante) {
        $this->idsolicitante = $idsolicitante;
    }

    function setDireccionSolicitante($direccionSolicitante) {
        $this->direccionSolicitante = $direccionSolicitante;
    }

    function setEmailSolicitante($emailSolicitante) {
        $this->emailSolicitante = $emailSolicitante;
    }

    function setDnipersonanatural($dnipersonanatural) {
        $this->dnipersonanatural = $dnipersonanatural;
    }

    function setApellidospersonanatural($apellidospersonanatural) {
        $this->apellidospersonanatural = $apellidospersonanatural;
    }

    function setNombrepersonanatural($nombrepersonanatural) {
        $this->nombrepersonanatural = $nombrepersonanatural;
    }

    function setRucpersonajuridica($rucpersonajuridica) {
        $this->rucpersonajuridica = $rucpersonajuridica;
    }

    function setRazonsocialpersonajuridica($razonsocialpersonajuridica) {
        $this->razonsocialpersonajuridica = $razonsocialpersonajuridica;
    }

    function setIddistrito($iddistrito) {
        $this->iddistrito = $iddistrito;
    }

    function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    function setClave($clave) {
        $this->clave = $clave;
    }

        
     public function  listar3ParametroSolicitante ($codigoDepartamento,$codigoProvincia,$codigoDistrito){
        
        try {
            $sql = "select * from f_listar_solicitante(:codigo_departamento, :codigo_provincia, :codigo_distrito)";
        $sentencia  = $this->dblink->prepare($sql);
        $sentencia->bindParam(":codigo_departamento",$codigoDepartamento);
        $sentencia->bindParam(":codigo_provincia",$codigoProvincia);
        $sentencia->bindParam(":codigo_distrito",$codigoDistrito);
        $sentencia->execute();
         
        $registros = $sentencia->fetchAll();
        
        return $registros;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    
   public function eliminar (){
        try {
           
            $sql ="delete from solicitante   where idsolicitante= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $this->getIdsolicitante());
            $sentencia->execute();
           
        } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
    
    public function cambiarestado(){
        
        try {
           
            $sql ="update solicitante  set estado ='A' where idsolicitante= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $this->getIdsolicitante());
            $sentencia->execute();
                
               } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
        public function activarCuenta($codigo_activacion){
        
        try {
           
            $sql ="update solicitante  set estado ='A' where codigo_activacion= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_activacion);
            $sentencia->execute();
                
               } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
    
     public function agregarSolicitanteSolicitante(){
        try {
            
            $codigo_activacion = md5($this->getEmailSolicitante());
                
                $sql = "insert into solicitante(direccion, dnipersonanatural, apellidospersonanatural, nombrepersonanatural,
                    rucpersonajuridica, razonsocialpersonajuridica, iddistrito, email, usuario, clave, codigo_activacion)
            values (:p_direccion, 
                    :p_dnipersonanatural,
                    :p_apellidospersonanatural, 
                    :p_nombrepersonanatural, 
                    :p_rucpersonajuridica, 
                    :p_razonsocialpersonajuridica,
                    :p_iddistrito, 
                    :p_email, 
                    :p_usuario, 
                    :p_clave,
                    :p_codigo_activacion)";
                $sentencia = $this->dblink->prepare($sql);
               
                $sentencia->bindParam(":p_direccion", $this->getDireccionSolicitante());
                $sentencia->bindParam(":p_dnipersonanatural", $this->getDnipersonanatural());
                $sentencia->bindParam(":p_apellidospersonanatural", $this->getApellidospersonanatural());
                $sentencia->bindParam(":p_nombrepersonanatural", $this->getNombrepersonanatural());
                $sentencia->bindParam(":p_rucpersonajuridica", $this->getRucpersonajuridica());
                $sentencia->bindParam(":p_razonsocialpersonajuridica", $this->getRazonsocialpersonajuridica());
                $sentencia->bindParam(":p_iddistrito", $this->getIddistrito());
                $sentencia->bindParam(":p_email", $this->getEmailSolicitante());
                $sentencia->bindParam(":p_usuario", $this->getUsuario());
                $sentencia->bindParam(":p_clave", $this->getClave());
                $sentencia->bindParam(":p_codigo_activacion", $codigo_activacion);
                $resultado = $sentencia->execute();
                
                if ($resultado)
                {
                    $to = $this->getEmailSolicitante();
                    $subject = "Activar cuenta de DOGESI";
                    $body = "Hola, para activar la cuenta ingresa al siguiente enlace: <br/>"
                            . "http://localhost/web-dogesiv3/vista/activar.php?codigo_activacion="
                            . $codigo_activacion;
                    
                    $objEmail = new Email();
                   $objEmail->enviarMensajeCorreo($to, $subject, $body);
                }
            
       } catch (Exception $exc) {
            echo $exc->getMessage();
        }
        return true;  
    }
    
    
    public function editar (){
            $this->dblink->beginTransaction();
        
        try {
            
                
                $sql = "UPDATE solicitante SET direccion=:p_direccion, dnipersonanatural=:p_dnipersonanatural, 
                apellidospersonanatural=:p_apellidospersonanatural, nombrepersonanatural=:p_nombrepersonanatural, 
                rucpersonajuridica=:p_rucpersonajuridica, razonsocialpersonajuridica=:p_razonsocialpersonajuridica, 
                iddistrito=:p_iddistrito, email=:p_email,
                usuario=:p_usuario, clave=:p_clave
                WHERE idsolicitante =:p_idsolicitante";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia ->bindParam(":p_idsolicitante",  $this->getIdsolicitante());
                $sentencia ->bindParam(":p_direccion",  $this->getDireccionSolicitante());
                $sentencia ->bindParam(":p_dnipersonanatural",  $this->getDnipersonanatural());
                $sentencia ->bindParam(":p_apellidospersonanatural",  $this->getApellidospersonanatural());
                $sentencia ->bindParam(":p_nombrepersonanatural",  $this->getNombrepersonanatural());
                $sentencia ->bindParam(":p_rucpersonajuridica",  $this->getRucpersonajuridica());
                $sentencia ->bindParam(":p_razonsocialpersonajuridica",  $this->getRazonsocialpersonajuridica());
                $sentencia ->bindParam(":p_iddistrito",  $this->getIddistrito());
                $sentencia ->bindParam(":p_email",  $this->getEmailSolicitante());
                $sentencia ->bindParam(":p_usuario",  $this->getUsuario());
                $sentencia ->bindParam(":p_clave",  $this->getClave());
                
                $sentencia ->execute();
                
                $this->dblink->commit();
                
            
        } catch (Exception $exc) {
            $this->dblink->rollBack();
            throw $exc;
        }
        return true;
        }
        
         public function leerDatos($codigo_solicitante) {
        try {
            $sql = "
                 select s.idsolicitante, s.direccion, s.dnipersonanatural, s.apellidospersonanatural, 
       s.nombrepersonanatural, s.rucpersonajuridica, s.razonsocialpersonajuridica, 
       s.email, s.usuario, s.clave, dis.iddistrito, p.idprovincia,d.iddepartamento
       from solicitante s
       inner join distrito dis on (s.iddistrito=dis.iddistrito)
       inner join provincia p on (dis.idprovincia=p.idprovincia)
       inner join departamento d on (p.iddepartamento=d.iddepartamento)
       where s.idsolicitante =:p_ca
                ";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_solicitante);
            $sentencia->execute();
            $resultado = $sentencia->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (Exception $exc) {
            throw $exc;
        }
            
    }


}
