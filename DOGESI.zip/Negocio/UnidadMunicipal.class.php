<?php

require_once '../Datos/Conexion.php';

class UnidadMunicipal extends Conexion{
    
    private $idunidadmunicipal;
    private $nombreunidadmunicipal;
    
    function getIdunidadmunicipal() {
        return $this->idunidadmunicipal;
    }

    function getNombreunidadmunicipal() {
        return $this->nombreunidadmunicipal;
    }

    function setIdunidadmunicipal($idunidadmunicipal) {
        $this->idunidadmunicipal = $idunidadmunicipal;
    }

    function setNombreunidadmunicipal($nombreunidadmunicipal) {
        $this->nombreunidadmunicipal = $nombreunidadmunicipal;
    }

public function obtenerUnidadMunicipal(){
        try {
            $sql = " select idunidadmunicipal,nombreunidadmunicipal from unidadmunicipal order by nombreunidadmunicipal";
            $sentencia  = $this->dblink->prepare($sql);
            $sentencia->execute();
            $resultado = $sentencia->fetchAll();
        
        return $resultado;
        } catch (Exception $exc) {
            echo $exc;
        }
    }
    
       public function eliminar (){
        try {
            $sql ="delete from unidadmunicipal   where idunidadmunicipal= :p_ca";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $this->getIdunidadmunicipal());
            $sentencia->execute();
        } catch (Exception $exc) {
            echo $exc;
        }
        return true;
    }
    
     public function agregarMotivoMovimiento(){
        try {
                $sql = "insert into unidadmunicipal(nombreunidadmunicipal)
            values (:p_nombre)";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia->bindParam(":p_nombre", $this->getNombreunidadmunicipal());
               $sentencia->execute();
            
       } catch (Exception $exc) {
            echo $exc;
        }
        return true;  
    }
    
    
    public function editar (){
            $this->dblink->beginTransaction();
        try { 
                $sql = "UPDATE unidadmunicipal SET nombreunidadmunicipal=:p_nombre
                WHERE idunidadmunicipal =:p_idunidadmunicipal";
                $sentencia = $this->dblink->prepare($sql);
                $sentencia ->bindParam(":p_idunidadmunicipal",  $this->getIdunidadmunicipal());
                $sentencia ->bindParam(":p_nombre",  $this->getNombreunidadmunicipal());
                $sentencia ->execute();
                $this->dblink->commit();
                
            
        } catch (Exception $exc) {
            $this->dblink->rollBack();
            throw $exc;
        }
        return true;
        }
        
         public function leerDatos($codigo_unidadmunicipal) {
        try {
            $sql = "
                 select idunidadmunicipal, nombreunidadmunicipal from unidadmunicipal where idunidadmunicipal =:p_ca ";
            $sentencia = $this->dblink->prepare($sql);
            $sentencia->bindParam(":p_ca", $codigo_unidadmunicipal);
            $sentencia->execute();
            $resultado = $sentencia->fetch(PDO::FETCH_ASSOC);
            return $resultado;
        } catch (Exception $exc) {
            throw $exc;
        }
            
    }

}
