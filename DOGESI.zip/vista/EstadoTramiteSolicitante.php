
<?php

    session_name("MPG");
    session_start();
    
    if(! isset ($_SESSION["usuario"])){
        header("location:index.php");
    }
    
    $nombreUsuario=  ucwords(strtolower($_SESSION["usuario"]));
 //   $cargo=ucwords(strtolower($_SESSION["cargo"]));
    
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title> BIENVENIDO A MPG</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="../util/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="../util/lte/css/font-awesome.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../util/lte/css/AdminLTE.css" rel="stylesheet" type="text/css" />
    
    <!-- DATA TABLE -->
    <link href="../util/lte/plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    
    <!-- Ionicons -->
    
    <!-- Theme style -->
    <link href="../util/lte/css/extras.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons -->
    
    <link href="../util/lte/css/ionicons.css" rel="stylesheet" type="text/css" />
    
    <!-- Theme style -->
    <link href="../util/lte/skins/_all-skins.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <!-- Site wrapper -->
    <div class="wrapper">
      
      <?php
      include './cabeceraSolicitante.php';
      ?>

      <!-- =============================================== -->

      <!-- Left side column. contains the sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <!-- sidebar: style can be found in sidebar.less -->
         <?php
            include './menuSolicitante.php';
         ?>
<!-- /.sidebar -->
        <!-- /.sidebar -->
      </aside>

      <!-- =============================================== -->

      <!-- Inicio: contenido de la pagina -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            ESTADO DEL TRAMITE
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Principal</a></li>
            <li><a href="#">Estado</a></li>
            <li class="active">Tramite</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            
            <!-- INICIO DE FORMULARIO MODAL -->
           
            
            <!-- FIN DE FORMULARIO MODAL -->
          <div class="row">
            <div class="col-xs-12">
              
              
              <div class="box">
                <div class="box-body">
                    
                    <div id="listado">
                           
                        
                        
<!--                        <table id="tbl-listado" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>AÑO</th>
									<th>HORA</th>
									<th>SOLICITANTE</th>
									<th>ASUNTO</th>
									<th>TRAMITE</th>
                                                                        <th>ESTADO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</thead>
							<tbody>
	
							</tbody>
							<tfoot>
								<tr>
									<th>AÑO</th>
									<th>HORA</th>
									<th>SOLICITANTE</th>
									<th>ASUNTO</th>
									<th>TRAMITE</th>
                                                                        <th>ESTADO</th>
                                                                        <th>&nbsp;</th>
								</tr>
							</tfoot>
						</table>-->

                        
                        
                    </div>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
      
      <!-- Fin: contenido de la pagina -->

      <footer class="main-footer">
        <div class="center-block hidden-xs">
          <b>Version</b> 1.0
          <b>**** MUNICIPALIDAD CP DE PAMPA GRANDE - CHICLAYO ****</b>
        </div>
          <strong>Copyright &copy; <?php echo date("Y");?> <a href="# ">Sistema Gestion de Tramite Documentario</a>.</strong> Todos los derechos reservados.
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->  
    <script src="../util/lte/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<!--    <script src="../vista/js/estadoTramite.js" type="text/javascript"></script>-->
    
    <script src="../util/jquery/jquery.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../util/bootstrap/js/bootstrap.js" type="text/javascript"></script>
    
    <!-- DATA TABLE-->
    <script src="../util/lte/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="../util/lte/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    
    <!-- SlimScroll -->
    
    <!-- FastClick -->
    <script src='../util/lte/plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="../util/lte/js/app.js" type="text/javascript"></script>
    <!-- Temas -->
    <script src="../util/lte/js/demo.js" type="text/javascript"></script>
    
    <script src="../vista/js/estadoTramite.js" type="text/javascript"></script>
 
    
<!--    <script>
    $(document).ready(function (){
        $("#tbl-listado").dataTable();
    });
    </script>-->
    
<!--    <script src="js/articulo.js"> </script>-->
  </body>
  
  
</html>