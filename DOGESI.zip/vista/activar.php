<?php
require_once '../Negocio/Solicitante.class.php';
header('Content-Type: text/html; charset=utf-8');
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(isset($_GET['codigo_activacion']))
{
    try
    {
        $objSolicitante = new Solicitante();
        $codigo_activacion = $_GET['codigo_activacion'];
        $resultado = $objSolicitante->activarCuenta($codigo_activacion);
        echo ($resultado==true)?'Cuenta activada.':'Error';
    } catch (Exception $ex) {
        $ex->getMessage();
    }
}
else
{
    exit('Error, codigo no válido.');
}