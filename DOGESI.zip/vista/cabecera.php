<header class="main-header" style="color: #000">
        <a  href="#" class="logo"><b>DOGESI</b> </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-default" role="navigation" style="background: #9491c4"> 
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
              <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        <div class="hidden-xs">
           <b>SISTEMA DE TRAMITE DOCUMENTARIO DE LA MUNICIPLIDAD DE PAMPA GRANDE - CHICLAYO</b>
        </div>
              
          </a>
          <div class="navbar-custom-menu" align="center" style="size: 40px">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              <!-- Notifications: style can be found in dropdown.less -->
              <!-- Tasks: style can be found in dropdown.less -->
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <img src="../imagenes/1.png" class="user-image" alt="User Image"/>
                    <span class="hidden-xs" align="center">
                        <?php
                        echo $nombreUsuario;
                        ?>
                        <br>
                        <?php
                        echo $cargo;
                        ?>
                    </span>
                </a>
                  <ul class="dropdown-menu" align="center" >
                  <!-- User image -->
                  <li class="user-header">
                    <img src="../imagenes/1.png" class="img-circle" alt="User Image" />
                    <p>
                      <?php
                        echo $nombreUsuario;
                        ?>
                        <br>
                        <?php
                        echo $cargo;
                        ?>
                      
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <li class="user-body">
                    
                    <div class="col-xs-12 text-center">
                        <a href="#"><i class="fa fa-key text-danger"></i><span class="text-primary"> Cambiar mi Contraceña</span></a>
                    </div>
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                        <a href="#" class="btn btn-default btn-flat"><i class="fa fa-user"></i> Perfil</a>
                    </div>
                    <div class="pull-right">
                        <a href="../Controlador/cerrarSesion.php" class="btn btn-default btn-flat"><i class="fa fa-power-off"></i> Cerrar Sesion</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>

