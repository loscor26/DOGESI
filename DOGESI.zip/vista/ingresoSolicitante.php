<?php
    if(isset($_COOKIE["usuario"])){
        $usuario=$_COOKIE["usuario"];
    }  else {
        $usuario="";
    }
?>

<?php
    $concatenar;
     $num = Array();
     reset($num);
     for($i=1;$i<=10;$i++) 
     {
       $num[$i]=rand(0,9);
        if($i>1) 
        {
           for($x=1; $x<$i; $x++)
           {
             if($num[$i]==$num[$x]) 
             { 
               $i--; 
               break; 
             }
          }
       }
     }
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>MPG </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="../util/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="../util/lte/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="../util/lte/css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="../util/lte/plugins/iCheck/square/aero.css" rel="stylesheet" type="text/css" />
    

  </head>
  <body class="login-page">
    <div class="login-box">
      <div class="login-logo row">
        <a href="../../index2.html">BIENVENIDO A LA BUSQUEDA DE SU TRAMITE </a>
      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">INGRESE SUS DATOS PARA INGRESAR SOLICITANTE</p>
        <form action="../Controlador/Sesion.controlador.solicitante.php" method="post">
          <div class="form-group has-feedback">
              <input type="text" class="form-control" placeholder="DIGITE SU USUARIO" autofocus="" name="txtusuario" value="<?php echo $usuario;?>"/>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
              <input type="password" class="form-control" placeholder="DIGITE SU CONTRACEÑA" name="txtclave" />
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
            
            <div class="row">
            <div class="col-xs-4">
              <button type="button" class="btn btn-dropbox" data-toggle="modal" data-target="#myModal" onclick="agregarManteniemientoSolicitante()">Registrarte</button>
            </div>
            
            <div class="col-xs-4">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Ingresar</button>
            </div><!-- /.col -->
            
            <div class="col-xs-4">
              <div class="pull-right">
                        <a href="../Controlador/cerrarSesion.php" class="btn btn-default btn-flat"><i class="fa fa-power-off"></i> Cancelar</a>
                    </div>
            </div><!-- /.col -->
          </div>
        </form>
            
            
            <!-- INICIO DE FORMULARIO MODAL -->
            <form name="frmgrabar" id="frmgrabar" method="post" action="../Controlador/enviarcorreo.php">
                <div class="modal fade" id="myModal" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Agregar nuevo Solicitante</h4>
                      </div>
                      <div class="modal-body">
                          <p><input type="hidden" name="txttipooperacion" id="txttipooperacion" class="form-control" required=""><p>
                          <div class="row">
                              <div class="col-xs-4">
                          <p><input type="text" name="txtIdUsuario" id="txtIdUsuario" class="form-control" placeholder="Numero de solicitante"readonly=""><p>
                          </div>
                               <div class="col-xs-4">
                              <p><input type="text" name="txtusuario" id="txtusuario" class="form-control" placeholder="Ingrese usuario" required=""><p>
                                  </div>
                              <div class="col-xs-4">
                                  <p><input type="text" name="txtclave" id="txtclave" class="form-control" placeholder="Ingrese clave" required=""><p>
                              </div>
                          </div>  
                          
                          
                          
                          <div class="row">
                              <div class="col-xs-6">
                              <p><input type="text" name="txtdireccionregistrosolicitante" id="txtdireccionregistrosolicitante" class="form-control" placeholder="Direccion" required=""><p>
                                </div>  
                              <div class="col-xs-6">
                              <p><input type="text" name="txtemailregistrarsolicitante" id="txtemailregistrarsolicitante" class="form-control" placeholder="Email" required=""><p> 
                          </div> 
                              </div> 
                          
                          <div class="row">
                              <div class="col-xs-4">
                              <p>
                                <select id="cbodepartamento_modal" name="cbodepartamento_modal" class="form-control" required="">

                                </select>
                                    </p>
                                    </div>
                            
                            <div class="col-xs-4">
                                <p>
                                <select id="cboprovincia_modal" name="cboprovincia_modal" class="form-control" required="">

                                </select>
                                    </p>
                            </div>
                            <div class="col-xs-4">
                                <p>
                                <select id="cbodistrito_modal" name="cbodistrito_modal" class="form-control" required="">

                                </select>
                                    </p>
                            </div>
                              </div>
                          
                          <div class="row">
                               <label>      PERSONA NATURAL (Llene los campos necesarios a continuacion)</label>
                               <div class="col-xs-4">
                                   <p><input type="text" name="txtnombrenatural" id="txtnombrenatural" class="form-control" placeholder="Nombre del Solicitante" value="-"></p> 
                                  </div> 
                              <div class="col-xs-4">    
                              <p><input type="text" name="txtapelidosnatural" id="txtapelidosnatural" class="form-control" placeholder="Apellidos del Solicitante" value="-"></p>
                                  </div> 
                              <div class="col-xs-4">   
                              <p><input type="text" name="txtdni" id="txtdni" class="form-control" placeholder="Dni" value="-"><p>
                                  </div> 
                          </div>      
                           
                          <div class="row">
                              <label>      PERSONA JURIDICA (Llene los campos necesarios a continuacion)</label>
                               <div class="col-xs-4">
                              <p><input type="text" name="txtrazonsocialpersonajuridica" id="txtrazonsocialpersonajuridica" class="form-control" placeholder="Razon Social" value="-"><p>
                                  </div> 
                              <div class="col-xs-4">
                              <p><input type="text" name="txtruc" id="txtruc" class="form-control" placeholder="RUC" value="-"><p>
                               </div>      
                            </div>     
                           
                      </div>
                      <div class="modal-footer">
                          <button type="submit" class="btn btn-danger" aria-hidden="true">Aceptar</button>
                          <button type="button" class="btn btn-default" data-dismiss="modal" id="btncerrar">Cancelar</button>
                      </div>
                        
                        
                    </div>
                  </div>
                </div>
            
            </form>
            <!-- FIN DE FORMULARIO MODAL -->
            
                         

          


       
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.3 -->
    <script src="../util/jquery/jquery.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="../util/bootstrap/js/bootstrap.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="../util/lte/plugins/iCheck/icheck.js" type="text/javascript"></script>
    
<!--    <script src="js/MantenimientoSolicitante.js" type="text/javascript"></script>-->
    <script src="../vista/js/MantenimientoSolicitante.js" type="text/javascript"></script>
    
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
  </body>
</html>