function cargarUnidadMunicipal(){
    $("#cbounidadmunicipal").load("../Controlador/listar.UnidadMunicipal.php?modal=0");
    $("#cbounidadmunicipal_moda").load("../Controlador/listar.UnidadMunicipal.php?modal=1");
}

$("#cbounidadmunicipal").change(function (){
     listar();
    });

function listar (){
    var codigo_unidadmunicipal= $("#cbounidadmunicipal").val();
    if (codigo_unidadmunicipal==null){
        codigo_unidadmunicipal = 0;
    }
    console.log("codigo_unidadmunicipal:"+codigo_unidadmunicipal);
   
    $.post("../Controlador/listar.Area.Mantenimiento.php",{
                p_codigo_unidadmunicipal: codigo_unidadmunicipal})
                
            .done (function (resultado){
                $("#listado").empty();
                $("#listado").append(resultado);
                $("#tbl-listado").dataTable();
                
    });
}


function eliminar(codigo){
    //alert ("El codigo para eliminar es: "+codigo);
    if( ! confirm("Esta sguro de eliminar el registro seleccionado")){
        return 0;
    }
    
    $.post("../Controlador/area.eliminar.php",{
        p_codigo_area : codigo
    }).done(function(resultado){
        if(resultado==="exito"){
            listar();
        } 
    }).fail(function(error){
        alert(error.responseText);
    });
}




$("#frmgrabar").submit(function (event){
    event.preventDefault();
    
    if(! confirm("Esta seguro de grabar los datos")){
        return 0;
    }
   $.post("../Controlador/area.agregar.editar.php",
   {
       p_array_datos: $("#frmgrabar").serialize()
   }
           ).done(function (resultado){
               
       if(resultado==="exito"){
           listar();
           $("#btncerrar").click();
       }
   }).fail(function (error){
      alert(error.responseText);
   })
    
});


function agregarManteniemientoSolicitante(){
   $("#myModalLabel").empty().append("Agregar nueva Area");
    $("#txttipooperacion").val("agregarmanteniemiento");
    
        $("#txtnombreareamantenimiento").val("");
        $("#txtsiglasareamantenimiento").val("");
//       $("#cbounidadmunicipal_moda").empty();
//       $("#cbounidadmunicipal_moda").val("");
            
}


function editar(codigo){
    $("#myModalLabel").empty().append("Editar datos del articulo");
    $("#txttipooperacion").val("editar");
    
    
    $.post("../Controlador/area.leerDatos.php",{
        p_codigo_area : codigo
    }).done(function(resultado){
        //alert(resultado);
        var datos = $.parseJSON(resultado);
        $("#txtnroarea").val(datos.idarea);
        $("#txtnombreareamantenimiento").val(datos.nombrearea);
        $("#txtsiglasareamantenimiento").val(datos.siglas);
        $("#cbounidadmunicipal_moda").val(datos.idunidadmunicipal);
        $("#cbounidadmunicipal_moda").change();
        
    }).fail(function(error){
        alert(error.responseText);
    });
}

$(document).ready(function (){
    cargarUnidadMunicipal();
    listar();
   
});



$("#myModal").on('show.bs.modal',function (){
    $("#txtnombreareamantenimiento").focus();
})









