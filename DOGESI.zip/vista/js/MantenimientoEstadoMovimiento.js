


 


function listar (){
    
    
    $.post("../Controlador/listar.EstadoMovimiento.php")
            .done (function (resultado){
                $("#listado").empty();
                $("#listado").append(resultado);
                $("#tbl-listado").dataTable();
                
    });
}

function eliminar(codigo){
    //alert ("El codigo para eliminar es: "+codigo);
    if( ! confirm("Esta sguro de eliminar el registro seleccionado")){
        return 0;
    }
    
    $.post("../Controlador/estadoMovimiento.eliminar.php",{
        p_codigo_estadomovimiendo : codigo
    }).done(function(resultado){
        if(resultado==="exito"){
            listar();
        } 
    }).fail(function(error){
        alert(error.responseText);
    });
}





$("#frmgrabar").submit(function (event){
    event.preventDefault();
    
    if(! confirm("Esta seguro de grabar los datos")){
        return 0;
    }
   $.post("../Controlador/estadoMovimiendo.agregar.editar.php",
   {
       p_array_datos: $("#frmgrabar").serialize()
   }
           ).done(function (resultado){
               
       if(resultado==="exito"){
           listar();
           $("#btncerrar").click();
       }
   }).fail(function (error){
      alert(error.responseText);
   })
    
});


function agregarManteniemientoSolicitante(){
   $("#myModalLabel").empty().append("Agregar nuevo Estado de Movimiento");
    $("#txttipooperacion").val("agregarmanteniemiento");
    
        $("#txtnombreestadotramitemantenimiendo").val("");
        
}


function editar(codigo){
    $("#myModalLabel").empty().append("Editar datos del Estado del Movimiento");
    $("#txttipooperacion").val("editar");
    
    
    $.post("../Controlador/estadoMovimiento.leerDatos.php",{
        p_codigo_estadomovimiendo : codigo
    }).done(function(resultado){
        //alert(resultado);
        var datos = $.parseJSON(resultado);
        $("#txtnroestadotramitemantenimiento").val(datos.idestadomovimiento);
        $("#txtnombreestadotramitemantenimiendo").val(datos.nombre);
       
        
    }).fail(function(error){
        alert(error.responseText);
    });
}

$(document).ready(function (){
   
     listar();
    
});



$("#myModal").on('show.bs.modal',function (){
    $("#txtnombreestadotramitemantenimiendo").focus();
})









