function cargarUnidadMunicipal(){
    $("#cbounidadmunicipal").load("../Controlador/listar.UnidadMunicipal.php?modal=0");
    $("#cbounidadmunicipal_moda").load("../Controlador/listar.UnidadMunicipal.php?modal=1");
}



function cargarArea(nombrecombo){
    
    $(nombrecombo).empty();
    var codigo_unidadmunicipal ="";
    var modal ="";
    if(nombrecombo=="#cboarea"){
        codigo_unidadmunicipal = $ ("#cbounidadmunicipal").val();
        modal="0";
    }else{
        codigo_unidadmunicipal = $("#cbounidadmunicipal_moda").val();
        modal="1";
    }
    $.post("../Controlador/listar.Area.php",{p_codigo_unidadmunicipal:codigo_unidadmunicipal, p_modal:modal })
            .done (function (resultado){   
                $(nombrecombo).empty();
                $(nombrecombo).append(resultado);
    })
    ;
    ;
}

 $("#cbounidadmunicipal").change(function (){
        cargarArea("#cboarea");
        listarCargo();
        
    });
    
    $("#cbounidadmunicipal_moda").change(function (){
        cargarArea("#cboarea_moda");
    });
    
 function listarCargo(){
    
    var codigo_unidadmunicipal= $("#cbounidadmunicipal").val();
    if (codigo_unidadmunicipal==null){
        codigo_unidadmunicipal = 0;
    }
    
     var codigo_area= $("#cboarea").val();
    if (codigo_area == null){
        codigo_area = 0;
    }
    
    
    
    console.log("codigo_unidadmunicipal:"+codigo_unidadmunicipal);
    console.log("codigo_area:"+codigo_area);
    
    $.post("../Controlador/listar.Area.Mantenimiento.php",{
                p_codigo_unidadmunicipal : codigo_unidadmunicipal,
                p_codigo_area      : codigo_area})
            .done (function (resultado){
                $("#listado").empty();
                $("#listado").append(resultado);
                $("#tbl-listado").dataTable();
                
    });
}   
    
 function eliminar(codigo){
    //alert ("El codigo para eliminar es: "+codigo);
    if( ! confirm("Esta sguro de eliminar el registro seleccionado")){
        return 0;
    }
    
    $.post("../Controlador/cargo.eliminar.php",{
        p_codigo_cargo : codigo
    }).done(function(resultado){
        if(resultado==="exito"){
            listarCargo()();
        } 
    }).fail(function(error){
        alert(error.responseText);
    });
}




$("#frmgrabar").submit(function (event){
    event.preventDefault();
    
    if(! confirm("Esta seguro de grabar los datos")){
        return 0;
    }
   $.post("../Controlador/cargo.agregar.editar.php",
   {
       p_array_datos: $("#frmgrabar").serialize()
   }
           ).done(function (resultado){
               
       if(resultado==="exito"){
            listarCargo();
           $("#btncerrar").click();
       }
   }).fail(function (error){
      alert(error.responseText);
   })
    
});


function agregarManteniemientoSolicitante(){
   $("#myModalLabel").empty().append("Agregar nueva Area");
    $("#txttipooperacion").val("agregarmanteniemiento");
    
        $("#txtnombrecargomantenimiento").val("");
       $("#cboarea_moda").empty();
 //      $("#cboarea_moda").val("");
            
}


function editar(codigo){
    $("#myModalLabel").empty().append("Editar datos del articulo");
    $("#txttipooperacion").val("editar");
    
    
    $.post("../Controlador/cargo.leerDatos.php",{
        p_codigo_cargo : codigo
    }).done(function(resultado){
        //alert(resultado);
        var datos = $.parseJSON(resultado);
        $("#txtnrocargo").val(datos.idcargo);
        $("#txtnombrecargomantenimiento").val(datos.nombrecargo);
        $("#cbounidadmunicipal_moda").val(datos.idunidadmunicipal);
        $("#cbounidadmunicipal_moda").change();
            $("#myModal").on('shown.bs.modal',function(){ 
                $("#cboarea_moda").val(datos.idarea);
                
            });
        
    }).fail(function(error){
        alert(error.responseText);
    });
}   
    
    
    
    
    
    
    
    
    
    
    
    
    
 

$(document).ready(function (){
    cargarUnidadMunicipal();
    listarCargo();
    
});


$("#myModal").on('show.bs.modal',function (){
    $("#txtnombrecargomantenimiento").focus();
})









