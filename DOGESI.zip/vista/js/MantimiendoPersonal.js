function cargarUnidadMunicipal(){
    $("#cbounidadmunicipal").load("../Controlador/listar.UnidadMunicipal.php?modal=0");
    $("#cbounidadmunicipal_modal").load("../Controlador/listar.UnidadMunicipal.php?modal=1");
}

function cargarArea(nombrecombo){
    
    $(nombrecombo).empty();
    var codigo_unidadmunicipal ="";
    var modal ="";
    if(nombrecombo=="#cboarea"){
        codigo_unidadmunicipal = $ ("#cbounidadmunicipal").val();
        modal="0";
    }else{
        codigo_unidadmunicipal = $("#cbounidadmunicipal_modal").val();
        modal="1";
    }
    $.post("../Controlador/listar.Area.php",{p_codigo_unidadmunicipal:codigo_unidadmunicipal, p_modal:modal })
            .done (function (resultado){   
                $(nombrecombo).empty();
                $(nombrecombo).append(resultado);
    })
    ;
    ;
}

function cargarCargo(nombrecombo){
    
    $(nombrecombo).empty();
    var codigo_area="";
    var modal ="";
    if(nombrecombo=="#cbocargo"){
        codigo_area = $ ("#cboarea").val();
        modal="0";
    }else{
        codigo_area = $("#cboarea_modal").val();
        modal="1";
    }
    $.post("../Controlador/listar.Cargo.php",{p_codigo_area:codigo_area, p_modal:modal })
            .done (function (resultado){   
                $(nombrecombo).empty();
                $(nombrecombo).append(resultado);
    })
    ;
    ;
}

 $("#cbounidadmunicipal").change(function (){
        cargarArea("#cboarea");
        listarPersonal();
    });
    
    $("#cbounidadmunicipal_modal").change(function (){
        cargarArea("#cboarea_modal");
    });
    
    $("#cboarea").change(function (){
        cargarCargo("#cbocargo");
        listarPersonal();
    });
    
    $("#cbocargo").change(function (){
        listarPersonal();
    });
    
    $("#cboarea_modal").change(function (){
        cargarCargo("#cbocargo_modal");
    });


function listarPersonal(){
    
    var codigo_unidadmunicipal= $("#cbounidadmunicipal").val();
    if (codigo_unidadmunicipal==null){
        codigo_unidadmunicipal = 0;
    }
    
     var codigo_area= $("#cboarea").val();
    if (codigo_area == null){
        codigo_area = 0;
    }
    
    var codigo_cargo= $("#cbocargo").val();
    if (codigo_cargo == null){
        codigo_cargo = 0;
    }
    
    console.log("codigo_unidadmunicipal:"+codigo_unidadmunicipal);
    console.log("codigo_area:"+codigo_area);
    console.log("codigo_cargo:"+codigo_cargo);
    
    $.post("../Controlador/lista.Personal.php",{
                p_codigo_unidadmunicipal : codigo_unidadmunicipal,
                p_codigo_area      : codigo_area,
                p_codigo_cargo  : codigo_cargo})
            .done (function (resultado){
                $("#listado").empty();
                $("#listado").append(resultado);
                $("#tbl-listado").dataTable();
                
    });
}



function editar(codigo_personal){
    $("#myModalLabel").empty().append("Editar datos del Personal Seleccionado");
    $("#txttipooperacion").val("edita");
        
    $.post("../Controlador/personal.leerDatos.php",{
        p_codigo_personal : codigo_personal
    }).done(function(resultado){
        //alert(resultado);
        var datos = $.parseJSON(resultado);
        $("#txtnropersonal").val(datos.idpersonal);
        $("#txtusuariopersonal").val(datos.usuario);
        $("#txtclavepersonal").val(datos.clave);
        $("#txtfechainiciopersonal").val(datos.fechainicio);
        $("#txtfechafinpersonal").val(datos.fechafin);
        $("#txtdireccionpersonal").val(datos.direccion);
        $("#txtemailpersonal").val(datos.email);
        $("#txtnombrepersonal").val(datos.nombre);
        $("#txtapellidospersonal").val(datos.apellidos);
        $("#txtdnipersonal").val(datos.dnipersonal);
        $("#cbounidadmunicipal_modal").val(datos.idunidadmunicipal);
        $("#cbounidadmunicipal_modal").change();
            $("#myModal").on('shown.bs.modal',function(){ 
                $("#cboarea_modal").val(datos.idarea);
                $("#cboarea_modal").change();
                $("#myModal").on('shown.bs.modal',function(){    
                      $("#cbocargo_modal").val(datos.idcargo);
                       // $("#cbocargo_modal").change();
                        
            });
            });
        
    }).fail(function(error){
        alert(error.responseText);
    });
}




function cambiarestado(codigo){
    //alert ("El codigo para cambiar es: "+codigo);
    if( ! confirm("Esta sguro de cambiar el estado del registro seleccionado")){
        return 0;
    }
    
    $.post("../Controlador/personal.cambiarestado.php",{
        p_codigo_personal : codigo
    }).done(function(resultado){
        if(resultado==="exito"){
            listarPersonal();
        } 
    }).fail(function(error){
        alert(error.responseText);
    });
}




function eliminar(codigo){
    //alert ("El codigo para eliminar es: "+codigo);
    if( ! confirm("Esta sguro de eliminar el registro seleccionado")){
        return 0;
    }
    
    $.post("../Controlador/personal.eliminar.php",{
        p_codigo_personal : codigo
    }).done(function(resultado){
        if(resultado==="exito"){
             listarPersonal();
        } 
    }).fail(function(error){
        alert(error.responseText);
    });
}

$("#frmgrabar").submit(function (event){
    event.preventDefault();
    
    if(! confirm("Esta seguro de grabar los datos")){
        return 0;
    }
   $.post("../Controlador/personal.registrar.php",
   {
       p_array_datos: $("#frmgrabar").serialize()
   }
           ).done(function (resultado){
               
       if(resultado==="exito"){
            listarPersonal();
           $("#btncerrar").click();
       }
   }).fail(function (error){
      alert(error.responseText);
   })
    
});





function agregarManteniemientoPersonal(){
   $("#myModalLabel").empty().append("Agregar nuevo Personal");
    $("#txttipooperacion").val("agregarmanteniemiento");
    
        $("#txtusuariopersonal").val("");
        $("#txtclavepersonal").val("");
        $("#txtfechainiciopersonal").val("");
        $("#txtfechafinpersonal").val("");
        $("#txtdireccionpersonal").val("");
        $("#txtemailpersonal").val("");
        $("#txtnombrepersonal").val("");
        $("#txtapellidospersonal").val("");
        $("#txtdnipersonal").val("");
        $("#cbocargo_modal").empty();
        $("#cbocargo_modal").val("");
            
}



$(document).ready(function (){
    cargarUnidadMunicipal();
    listarPersonal();
    
});


$("#myModal").on('show.bs.modal',function (){
    $("#txtusuariopersonal").focus();
})








