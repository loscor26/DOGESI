function cargarDepartamento(){
    $("#cbodepartamento").load("../Controlador/listar.Departamento.php?modal=0");
    $("#cbodepartamento_modal").load("../Controlador/listar.Departamento.php?modal=1");
}

function cargarProvincia(nombrecombo){
    
    $(nombrecombo).empty();
    var codigo_departamento ="";
    var modal ="";
    if(nombrecombo=="#cboprovincia"){
        codigo_departamento = $ ("#cbodepartamento").val();
        modal="0";
    }else{
        codigo_departamento = $("#cbodepartamento_modal").val();
        modal="1";
    }
    $.post("../Controlador/listar.Provincia.php",{p_codigo_departamento:codigo_departamento, p_modal:modal })
            .done (function (resultado){   
                $(nombrecombo).empty();
                $(nombrecombo).append(resultado);
    })
    ;
    ;
}

function cargarDistrito(nombrecombo){
    
    $(nombrecombo).empty();
    var codigo_provincia ="";
    var modal ="";
    if(nombrecombo=="#cbodistrito"){
        codigo_provincia = $ ("#cboprovincia").val();
        modal="0";
    }else{
        codigo_provincia = $("#cboprovincia_modal").val();
        modal="1";
    }
    $.post("../Controlador/listar.Distrito.php",{p_codigo_provincia:codigo_provincia, p_modal:modal })
            .done (function (resultado){   
                $(nombrecombo).empty();
                $(nombrecombo).append(resultado);
    })
    ;
    ;
}

 $("#cbodepartamento").change(function (){
        cargarProvincia("#cboprovincia");
     listar();
    });
    
    $("#cbodepartamento_modal").change(function (){
        cargarProvincia("#cboprovincia_modal");
    });
    
    $("#cboprovincia").change(function (){
        cargarDistrito("#cbodistrito");
        listar();
    });
    
    $("#cbodistrito").change(function (){
        listar();
    });
    
    $("#cboprovincia_modal").change(function (){
        cargarDistrito("#cbodistrito_modal");
    });


function listar (){
    var codigo_departamento= $("#cbodepartamento").val();
    if (codigo_departamento==null){
        codigo_departamento = 0;
    }
    
     var codigo_provincia= $("#cboprovincia").val();
    if (codigo_provincia == null){
        codigo_provincia = 0;
    }
    
    var codigo_distrito= $("#cbodistrito").val();
    if (codigo_distrito == null){
        codigo_distrito = 0;
    }
    
    console.log("codigo_departamento:"+codigo_departamento);
    console.log("codigo_provincia:"+codigo_provincia);
    console.log("codigo_distrito:"+codigo_distrito);
    
    $.post("../Controlador/listaSolicitante.php",{
                p_codigo_departamento:codigo_departamento,
                p_codigo_provincia      : codigo_provincia,
                p_codigo_distrito  : codigo_distrito})
            .done (function (resultado){
                $("#listado").empty();
                $("#listado").append(resultado);
                $("#tbl-listado").dataTable();
                
    });
}

function eliminar(codigo){
    //alert ("El codigo para eliminar es: "+codigo);
    if( ! confirm("Esta sguro de eliminar el registro seleccionado")){
        return 0;
    }
    
    $.post("../Controlador/solicitante.eliminar.php",{
        p_codigo_solicitante : codigo
    }).done(function(resultado){
        if(resultado==="exito"){
            listar();
        } 
    }).fail(function(error){
        alert(error.responseText);
    });
}




$("#frmgrabar").submit(function (event){
    
    event.preventDefault();
    
    if(! confirm("Esta seguro de grabar los datos")){
        return 0;
    }
   $.post("../Controlador/solicitante.registrar.php",
   {
       p_array_datos: $("#frmgrabar").serialize()
   }
           ).done(function (resultado){
               
       if(resultado==="exito"){
            listar();
           $("#btncerrar").click();
       }
   }).fail(function (error){
      alert(error.responseText);
   })
    
});


function agregar(){
   
    $("#txttipooperacion").val("agregar");
        $("#txtdireccionregistrosolicitante").val("");
        $("#txtdni").val("");
        $("#txtapelidosnatural").val("");
        $("#txtnombrenatural").val("");
        $("#txtruc").val("");
        $("#txtrazonsocialpersonajuridica").val("");
        $("#txtemailregistrarsolicitante").val("");
        $("#txtusuario").val("");
        $("#txtclave").val("");
        $("#cbodistrito").empty();
        $("#cbodistrito").val("");
            
}




    
    

$(document).ready(function (){
    cargarDepartamento();
     listar();
});






$("#myModal").on('show.bs.modal',function (){
    $("#txtnombre").focus();
})









