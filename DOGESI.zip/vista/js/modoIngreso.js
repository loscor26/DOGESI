
$("#btnsolicitante").click(function(){ // al hacer click lo transfiere a otro archivo : comprar,php
   document.location.href="Vista/ingresoSolicitante.php";    
});

$("#btncolaborador").click(function(){
   document.location.href="Vista/ingresoColaborador.php";
});
