<body class="skin-blue">
<section class="sidebar"  >
    <!-- Sidebar user panel -->
    
    <!-- search form -->
    <form action="#" method="get" class="sidebar-form">
      <div class="input-group">
        <input type="text" name="q" class="form-control" placeholder="Buscar"/>
        <span class="input-group-btn">
          <button type='submit' name='seach' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
        </span>
      </div>
    </form>
    <!-- /.search form -->
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" >
      <li class="header">Menú Principal</li>

      <li class="treeview">
        <a href="#">
          <i class="fa fa-edit"></i> <span>Mantenimientos</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
            <li><a href="MantenimientoSolicitante.php"><i class="fa fa-user-md"></i> Solicitante</a></li>
          <li class="menu-division"></li>
          <li><a href="MantenimientoPersonal.php"><i class="fa fa-user"></i> Personal</a></li>
          
          <li class="menu-division"></li>
          <li><a href="EstadoMovimientoMantenimiento.php"><i class="fa fa-text-width"></i> Estado del Tramite</a></li>
          <li><a href="MotivoMovimientoMantenimiento.php"><i class="fa fa-text-width"></i> Motivo del Tramite</a></li>
          
           <li class="menu-division"></li>
           <li><a href="UnidadMunicipalMantenimiento.php"><i class="fa fa-medium"></i> Unidad Municipal</a></li>
           <li><a href="AreaMantenimiento.php"><i class="fa fa-medium"></i> Area</a></li>
           <li><a href="CargoMantenimiento.php"><i class="fa fa-medium"></i> Cargo</a></li>
          
       
         
          
        </ul>
      </li>

      <li class="treeview">
        <a href="#">
          <i class="fa fa-laptop"></i>
          <span> Sistemas de Tramite</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
            <li><a href="tramite-listado.php"><i class="fa fa-text-width"></i> Tramite</a></li>
           <!--  <li><a href="#"><i class="fa fa-text-width"></i> Movimiento del Tramite</a></li> -->
          
        </ul>
      </li>

      <li class="treeview">
        <a href="#">
            <i class="fa fa-book"></i> <span>Reportes</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><a href="#"><i class="fa fa-file-text"></i> Solicitante</a></li>
          <li class="menu-division"></li>
          <li><a href="#"><i class="fa fa-file-text"></i> Tramite</a></li>
        </ul>
      </li>

      

      <li class="treeview">
        <a href="#">
          <i class="fa fa-gears"></i> <span>Administración</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="treeview-menu">
          <li><a href="../forms/general.html"><i class="fa fa-user"></i> Usuarios</a></li>
          <li><a href="../forms/advanced.html"><i class="fa fa-key"></i> Cambiar Contraseña</a></li>
        </ul>
      </li>

    </ul>
</section>
     </body>