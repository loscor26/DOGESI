<?php
require_once '../phpmailer/PHPMailerAutoload.php';
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
            $mail = new PHPMailer();
            $mail->isSMTP();
            $mail->SMTPDebug = 2;
            $mail->Debugoutput = 'html';
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            //Whether to use SMTP authentication
$mail->SMTPAuth = true;
//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = "styck2603@gmail.com";
//Password to use for SMTP authentication
$mail->Password = "programacion3";
//Set who the message is to be sent from
$mail->setFrom('styck2603@gmail.com', 'First Last');

$mail->addAddress('coroneltc@gmail.com', 'John Doe');
//Set the subject line
$mail->Subject = 'PHPMailer GMail SMTP test';
$mail->msgHTML('Mensaje de prueba.');
if (!$mail->send()) 
    {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}